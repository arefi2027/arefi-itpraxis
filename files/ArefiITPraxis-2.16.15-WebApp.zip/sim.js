/* Arefi ITPraxis – Einsatz-Simulationen: Fälle mit Entscheidungen und Folgen (Zeit, Kundenzufriedenheit, Risiko).
   Daten in sim-data.js. Fortschritt lokal im Browser (localStorage), kein Konto, kein Server. */
(() => {
'use strict';
const KEY = 'arefi-sim';
const I = () => ({ fa: 0, de: 1, en: 2 })[document.documentElement.lang] ?? 0;
const T = (fa, de, en) => [fa, de, en][I()];
const P = a => Array.isArray(a) ? a[I()] : a;
const E = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const num = v => I() === 0 ? String(v).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]) : String(v);
const pc = v => I() === 0 ? num(v) + '٪' : v + ' %';
/* In Persisch lateinische Fachbegriffe isolieren, damit z. B. _ldap._tcp nicht durch die Schreibrichtung verdreht wird */
const LAT = /(?<![&#\w])[A-Za-z_](?:[\w.\/:\\-]*[\w\/])?(?: [A-Za-z_](?:[\w.\/:\\-]*[\w\/])?)*/g;
const B = s => I() === 0 ? E(s).replace(LAT, m => `<bdi>${m}</bdi>`) : E(s);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const DATA = () => window.ArefiSimData || [];
const byId = id => DATA().find(s => s.id === id) || null;
/* Vertiefung im Kurs je Fall */
const LINKS = { anmeldung: ['wscourse/ws-dnsdhcp', 'k-ops/ops-itil'], phishing: ['k-sec/sec-phish', 'k-m365/m365-mfa'], switch: ['k-net/net-vlan', 'k-msp/msp-vendor'], onboarding: ['k-msp/msp-onboard', 'k-m365/m365-entra'] };
function load() { try { const s = JSON.parse(localStorage.getItem(KEY) || '{}'); return Object.assign({ runs: {}, best: {} }, s && typeof s === 'object' ? s : {}); } catch { return { runs: {}, best: {} }; } }
function save(st) { try { localStorage.setItem(KEY, JSON.stringify(st)); } catch { /* Speicher voll oder gesperrt */ } }
const fresh = s => ({ node: s.start, log: [], m: [0, 3, 1], fb: null, done: false });
function valid(run, s) { return run && s && (run.done || s.nodes[run.node]) && Array.isArray(run.log) && Array.isArray(run.m); }

const QL = q => [['مسئله‌ساز', 'Problematisch', 'Problematic'], ['قابل قبول', 'Vertretbar', 'Acceptable'], ['تصمیم حرفه‌ای', 'Profi-Entscheidung', 'Professional decision']][q];
const QI = q => ['✗', '~', '✓'][q];
const riskTxt = r => r <= 1 ? T('کم', 'niedrig', 'low') : r <= 3 ? T('متوسط', 'mittel', 'medium') : T('بالا', 'hoch', 'high');
function meters(m, prev) {
 const ch = (i, good) => { if (!prev || prev[i] === m[i]) return ''; const up = m[i] > prev[i]; const ok = good ? up : !up; return ` <span class="sim-d ${ok ? 'is-good' : 'is-bad'}">${up ? '▲' : '▼'}<span class="visually-hidden">${E(ok ? T('بهتر شد', 'besser', 'better') : T('بدتر شد', 'schlechter', 'worse'))}</span></span>`; };
 return `<ul class="sim-meters" aria-label="${E(T('وضعیت', 'Stand', 'Status'))}">
 <li><span>${E(T('زمان مصرف‌شده', 'Verbrauchte Zeit', 'Time used'))}</span><b>${E(T(`${num(m[0])} دقیقه`, `${m[0]} Min.`, `${m[0]} min`))}</b></li>
 <li><span>${E(T('رضایت مشتری', 'Kundenzufriedenheit', 'Client satisfaction'))}</span><b>${E(T(`${num(m[1])} از ۵`, `${m[1]} von 5`, `${m[1]} of 5`))}</b>${ch(1, true)}<i class="sim-pips" aria-hidden="true">${[1, 2, 3, 4, 5].map(k => `<span class="${k <= m[1] ? 'on' : ''}"></span>`).join('')}</i></li>
 <li><span>${E(T('ریسک', 'Risiko', 'Risk'))}</span><b>${E(riskTxt(m[2]))}</b>${ch(2, false)}<i class="sim-pips is-risk" aria-hidden="true">${[1, 2, 3, 4, 5].map(k => `<span class="${k <= m[2] ? 'on' : ''}"></span>`).join('')}</i></li></ul>`;
}
function steps(s) { let n = 0, k = s.start; const seen = new Set(); while (k && k !== 'end' && !seen.has(k)) { seen.add(k); n++; const nd = s.nodes[k]; k = (nd.c.find(c => c.q === 2) || nd.c[0]).to; } return n; }
function score(log, s) { if (!log.length) return 0; return Math.round(100 * log.reduce((n, x) => n + s.nodes[x.n].c[x.c].q, 0) / (2 * log.length)); }

function listPage() {
 const st = load(), R = (window.ArefiBook && window.ArefiBook.roles) ? window.ArefiBook.roles() : {};
 const card = s => {
  const run = st.runs[s.id], best = st.best[s.id];
  const going = run && !run.done && run.log.length;
  const btn = going ? T('ادامه', 'Fortsetzen', 'Continue') : best != null ? T('دوباره بازی کن', 'Nochmal spielen', 'Play again') : T('شروع', 'Starten', 'Start');
  return `<li class="sim-card"><h2><a href="#einsatz/${s.id}">${E(P(s.title))}</a></h2><p>${B(P(s.lead))}</p>
  <p class="sim-meta">${s.role.map(r => R[r] ? `<span class="sim-role">${E(P(R[r]))}</span>` : '').join('')}<span>${E(T(`حدود ${num(s.mins)} دقیقه · ${num(steps(s))} تصمیم`, `ca. ${s.mins} Minuten · ${steps(s)} Entscheidungen`, `about ${s.mins} minutes · ${steps(s)} decisions`))}</span>${best != null ? `<span class="sim-best">${E(T('بهترین نتیجه: ', 'Bestes Ergebnis: ', 'Best result: '))}${E(pc(best))}</span>` : ''}</p>
  <p><a class="btn${going ? '' : ' secondary'}" href="#einsatz/${s.id}">${E(btn)}</a></p></li>`;
 };
 return `<div class="sim" id="sim-root">
 <header class="sim-head"><p class="sim-kicker">${E(T('تمرین', 'Üben', 'Practice'))}</p><h1 tabindex="-1">${E(title())}</h1>
 <p class="sim-lead">${E(T('موقعیت‌های واقعی کار در شرکت خدمات IT: در هر قدم تصمیم می‌گیری و پیامدش را می‌بینی – روی زمان، رضایت مشتری و ریسک. در پایان می‌بینی یک حرفه‌ای چه می‌کرد.', 'Echte Situationen aus dem Alltag beim IT-Dienstleister: Bei jedem Schritt entscheidest du und siehst die Folgen – für Zeit, Kundenzufriedenheit und Risiko. Am Ende siehst du, was ein Profi getan hätte.', 'Real situations from work at an IT service provider: at each step you decide and see the consequences – for time, client satisfaction and risk. At the end you see what a professional would have done.'))}</p></header>
 <ol class="sim-list">${DATA().map(card).join('')}</ol>
 <p class="sim-note">${E(T('شرکت‌ها و افراد ساختگی‌اند. نکته‌های حقوقی آموزشی‌اند و مشاورهٔ حقوقی نیستند.', 'Firmen und Personen sind erfunden. Rechtliche Hinweise dienen dem Lernen und sind keine Rechtsberatung.', 'Companies and people are fictitious. Legal notes are for learning and are not legal advice.'))}</p></div>`;
}

function resultHtml(s, run) {
 const p = score(run.log, s);
 const verdict = p >= 85 ? T('مثل یک حرفه‌ای', 'Wie ein Profi', 'Like a professional') : p >= 60 ? T('خوب – با جای پیشرفت', 'Solide – mit Luft nach oben', 'Solid – with room to improve') : T('یک بار دیگر تمرین کن', 'Noch einmal üben', 'Practise once more');
 const items = run.log.map(x => {
  const nd = s.nodes[x.n], ch = nd.c[x.c], best = nd.c.find(c => c.q === 2);
  return `<li class="sim-rv sim-q${ch.q}"><h3>${E(nd.at)} · ${E(P(nd.k))}</h3>
  <p><span class="sim-tag sim-q${ch.q}">${QI(ch.q)} ${E(P(QL(ch.q)))}</span> ${B(P(ch.t))}</p>
  ${ch.q < 2 && best ? `<p class="sim-better"><b>${E(T('کار حرفه‌ای:', 'So macht es ein Profi:', 'What a professional does:'))}</b> ${B(P(best.t))}</p>` : ''}</li>`;
 }).join('');
 const L = (LINKS[s.id] || []).map(h => { const r = window.ArefiBook && window.ArefiBook.modRef ? window.ArefiBook.modRef(h) : null; return r ? `<a href="${E(r.href)}">${r.no ? E(r.no) + ' ' : ''}${E(r.t)}</a>` : ''; }).join('');
 return `<section class="sim-result" aria-labelledby="sim-res-h"><h2 id="sim-res-h" tabindex="-1">${E(T('نتیجه', 'Ergebnis', 'Result'))}: ${E(pc(p))} – ${E(verdict)}</h2>
 ${meters(run.m)}
 <h3 class="sim-sub">${E(T('مرور تصمیم‌ها', 'Deine Entscheidungen im Rückblick', 'Your decisions in review'))}</h3><ol class="sim-review">${items}</ol>
 ${L ? `<p class="sim-links"><b>${E(T('برای عمیق‌تر شدن:', 'Vertiefen:', 'Go deeper:'))}</b> ${L}</p>` : ''}
 <div class="sim-row"><button type="button" class="btn" data-sim="restart">${E(T('دوباره بازی کن', 'Nochmal spielen', 'Play again'))}</button><a class="btn secondary" href="#einsatz">${E(T('همهٔ موقعیت‌ها', 'Alle Einsätze', 'All scenarios'))}</a></div></section>`;
}

function runPage(id) {
 const s = byId(id); if (!s) return listPage();
 const st = load(); let run = st.runs[id];
 if (!valid(run, s)) { run = fresh(s); st.runs[id] = run; save(st); }
 const total = steps(s);
 let body;
 if (run.fb) {
  const nd = s.nodes[run.fb.n], ch = nd.c[run.fb.c];
  body = `<section class="sim-fb sim-q${ch.q}" aria-labelledby="sim-fb-h"><p class="sim-yours"><b>${E(T('تصمیم تو:', 'Deine Entscheidung:', 'Your decision:'))}</b> ${B(P(ch.t))}</p>
  <h2 id="sim-fb-h" tabindex="-1">${E(T('پیامد', 'Folge', 'Consequence'))} <span class="sim-tag sim-q${ch.q}">${QI(ch.q)} ${E(P(QL(ch.q)))}</span></h2><p>${B(P(ch.fb))}</p>
  ${meters(run.m, run.fb.prev)}
  <div class="sim-row"><button type="button" class="btn" data-sim="next">${E(ch.to === 'end' ? T('دیدن نتیجه', 'Ergebnis ansehen', 'See result') : T('ادامه', 'Weiter', 'Continue'))}</button></div></section>`;
 } else if (run.done) body = resultHtml(s, run);
 else {
  const nd = s.nodes[run.node];
  body = `${meters(run.m)}<section class="sim-node" aria-labelledby="sim-node-h"><p class="sim-pos">${E(T(`تصمیم ${num(run.log.length + 1)} از حدود ${num(total)}`, `Entscheidung ${run.log.length + 1} von etwa ${total}`, `Decision ${run.log.length + 1} of about ${total}`))}</p>
  <h2 id="sim-node-h" tabindex="-1"><span class="sim-at">${E(nd.at)}</span> ${E(P(nd.k))}</h2><p class="sim-text">${B(P(nd.text))}</p>
  <h3 class="sim-sub">${E(T('چه می‌کنی؟', 'Was tust du?', 'What do you do?'))}</h3>
  <ol class="sim-choices">${nd.c.map((c, i) => `<li><button type="button" data-sim="pick" data-i="${i}">${B(P(c.t))}</button></li>`).join('')}</ol></section>`;
 }
 return `<div class="sim" id="sim-root" data-id="${E(id)}">
 <p class="sim-back"><a href="#einsatz">${E(T('همهٔ موقعیت‌ها', 'Alle Einsätze', 'All scenarios'))}</a></p>
 <header class="sim-head"><p class="sim-kicker">${E(T('شبیه‌سازی مأموریت', 'Einsatz-Simulation', 'Scenario simulation'))}</p><h1 tabindex="-1">${E(P(s.title))}</h1>
 <p class="sim-lead">${B(P(s.lead))}</p></header>
 ${body}
 ${!run.done && run.log.length ? `<p class="sim-restart"><button type="button" class="linklike" data-sim="restart">${E(T('از اول شروع کن', 'Von vorn beginnen', 'Start over'))}</button></p>` : ''}
</div>`;
}

function title() { return T('شبیه‌سازی مأموریت: تصمیم و پیامد', 'Einsatz-Simulationen: Entscheiden mit Folgen', 'Scenario simulations: decisions with consequences'); }
function page(focus) { return focus ? runPage(focus) : listPage(); }
function draw(sel) {
 const r = document.querySelector('#sim-root'); if (!r) return;
 const id = r.dataset.id; r.outerHTML = page(id || '');
 const f = sel && document.querySelector(sel); if (f) f.focus({ preventScroll: false });
}
let wired = false;
function mount() {
 if (wired) return; wired = true;
 document.addEventListener('click', e => {
  const b = e.target.closest('#sim-root [data-sim]'); if (!b) return;
  const id = document.querySelector('#sim-root').dataset.id, s = byId(id); if (!s) return;
  const st = load(); let run = st.runs[id]; if (!valid(run, s)) run = st.runs[id] = fresh(s);
  const k = b.dataset.sim;
  if (k === 'restart') { st.runs[id] = fresh(s); save(st); draw('#sim-node-h'); return; }
  if (k === 'pick' && !run.fb && !run.done) {
   const i = +b.dataset.i, c = s.nodes[run.node].c[i]; if (!c) return;
   const prev = run.m.slice();
   run.m = [run.m[0] + c.d[0], clamp(run.m[1] + c.d[1], 0, 5), clamp(run.m[2] + c.d[2], 0, 5)];
   run.log.push({ n: run.node, c: i }); run.fb = { n: run.node, c: i, prev };
   save(st); draw('#sim-fb-h'); return;
  }
  if (k === 'next' && run.fb) {
   const c = s.nodes[run.fb.n].c[run.fb.c]; run.fb = null;
   if (c.to === 'end' || !s.nodes[c.to]) { run.done = true; const p = score(run.log, s); st.best[id] = Math.max(st.best[id] || 0, p); save(st); draw('#sim-res-h'); }
   else { run.node = c.to; save(st); draw('#sim-node-h'); }
  }
 });
}
window.ArefiExt = window.ArefiExt || {};
window.ArefiExt.einsatz = { page: f => page(f), title, mount: f => { mount(); const h = document.querySelector('#sim-root h1'); if (h && document.activeElement === document.body) h.focus({ preventScroll: true }); } };
window.ArefiSim = { load, score, steps };
})();
