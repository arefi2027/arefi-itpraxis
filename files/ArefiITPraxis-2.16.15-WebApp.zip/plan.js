/* Arefi ITPraxis – „Mein Lernplan“: Zielberuf und Lernzeit wählen, Bereitschaft je Lernpfad sehen, konkreter Wochenplan mit Enddatum.
   Bereitschaft = 50 % erledigte Module + 30 % sichere Karten aus „Heute wiederholen“ + 20 % letzte Abschlussprüfung (je verfügbarem Teil gewichtet).
   Alles bleibt lokal im Browser (localStorage), kein Konto, kein Server. */
(() => {
'use strict';
const KEY = 'arefi-plan';
const HOURS = [2, 4, 6, 10, 15], PER_MOD = 1.5, REVIEW_H = 1; // Stunden pro Modul, Stunden pro Woche für die tägliche Wiederholung
const I = () => ({ fa: 0, de: 1, en: 2 })[document.documentElement.lang] ?? 0;
const T = (fa, de, en) => [fa, de, en][I()];
const P = a => Array.isArray(a) ? a[I()] : a;
const E = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const num = v => I() === 0 ? String(v).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]) : String(v);
const pc = v => I() === 0 ? num(v) + '٪' : v + ' %';
const LOC = () => ['fa-IR-u-ca-gregory', 'de-AT', 'en-GB'][I()];
const fmtDate = d => d.toLocaleDateString(LOC(), { day: 'numeric', month: 'long', year: 'numeric' });
function load() { try { const s = JSON.parse(localStorage.getItem(KEY) || '{}'); return Object.assign({ role: '', hours: 6, date: '' }, s && typeof s === 'object' ? s : {}); } catch { return { role: '', hours: 6, date: '' }; } }
function save(st) { try { localStorage.setItem(KEY, JSON.stringify(st)); } catch { /* Speicher voll oder gesperrt */ } }

const LEVELS = [
 [25, ['در آغاز راه', 'am Anfang', 'just starting'], 'l0'],
 [55, ['در حال ساختن', 'im Aufbau', 'building up'], 'l1'],
 [80, ['تقریباً آماده', 'fast bereit', 'almost ready'], 'l2'],
 [101, ['آماده', 'bereit', 'ready'], 'l3']
];
const level = v => LEVELS.find(l => v < l[0]);
/* Übung je Zielberuf, die jede Woche dazukommt */
const PRACTICE = {
 helpdesk: ['#ticketdesk', ['یک تیکت در میز تیکت حل کن', 'Ein Ticket am Ticketdesk lösen', 'Solve one ticket at the ticket desk']],
 onsite: ['#einsatz', ['یک شبیه‌سازی مأموریت را تا آخر بازی کن', 'Eine Einsatz-Simulation durchspielen', 'Play through one scenario simulation']],
 admin: ['#lab', ['یک تمرین در آزمایشگاه سرور انجام بده', 'Eine Übung im Server-Labor machen', 'Do one exercise in the server lab']],
 fisi: ['#k-ap', ['یک بخش از آمادگی آزمون AP کار کن', 'Einen Teil der AP-Prüfungsvorbereitung bearbeiten', 'Work through one part of the AP exam preparation']],
 net: ['#subnetz', ['۱۰ تمرین Subnetting حل کن', '10 Subnetting-Aufgaben lösen', 'Solve 10 subnetting tasks']]
};

function examLast() { try { const s = window.ArefiExam && window.ArefiExam.load ? window.ArefiExam.load() : JSON.parse(localStorage.getItem('arefi-exam') || '{}'); return (s && s.last) || null; } catch { return null; } }
let EXN = null;
function examNos() { if (EXN) return EXN; try { EXN = new Set(window.ArefiBook.examPaths().filter(p => p.qs.length).map(p => p.no)); } catch { EXN = new Set(); } return EXN; }

function readiness(p, rv, last) {
 const parts = [];
 if (p.tot) parts.push([p.done / p.tot, 0.5, 'mod']);
 const r = rv[p.no]; if (r && r.total) parts.push([r.firm / r.total, 0.3, 'rev']);
 if (examNos().has(p.no)) { const e = last && last.per ? last.per.find(x => x.no === p.no) : null; parts.push([e && e.n ? e.ok / e.n : 0, 0.2, 'exam']); }
 const w = parts.reduce((n, x) => n + x[1], 0);
 const v = w ? Math.round(100 * parts.reduce((n, x) => n + x[0] * x[1], 0) / w) : 0;
 const e = last && last.per ? last.per.find(x => x.no === p.no) : null;
 return { v, mod: [p.done, p.tot], rev: r ? [r.firm, r.total] : null, exam: examNos().has(p.no) ? (e ? [e.ok, e.n] : null) : undefined, hasExam: examNos().has(p.no) };
}

function compute(st) {
 const B = window.ArefiBook;
 const ps = B && B.planData ? B.planData() : [];
 const rv = window.ArefiReview && window.ArefiReview.byPath ? window.ArefiReview.byPath() : {};
 const last = examLast();
 const rows = ps.map(p => Object.assign({}, p, { r: readiness(p, rv, last), mine: !st.role || p.roles.includes(st.role) }));
 const mine = rows.filter(x => x.mine);
 const overall = mine.length ? Math.round(mine.reduce((n, x) => n + x.r.v, 0) / mine.length) : 0;
 const rest = mine.flatMap(x => x.rest.map(m => Object.assign({ no: x.no }, m)));
 const perWeek = Math.max(1, Math.floor((st.hours - REVIEW_H) / PER_MOD));
 const weeks = Math.ceil(rest.length / perWeek);
 const finish = new Date(); finish.setDate(finish.getDate() + weeks * 7);
 let target = null;
 if (st.date) {
  const d = new Date(st.date + 'T12:00:00'), days = Math.ceil((d - new Date()) / 864e5);
  if (!isNaN(days)) {
   const wa = Math.max(1, Math.ceil(days / 7)), need = Math.ceil(rest.length / wa);
   target = { d, past: days < 0, ok: weeks <= wa, spare: wa - weeks, needH: Math.ceil(need * PER_MOD + REVIEW_H) };
  }
 }
 const weakest = mine.slice().sort((a, b) => a.r.v - b.r.v)[0] || null;
 return { rows, mine, overall, rest, perWeek, weeks, finish, target, weakest, last };
}

function setupHtml(st) {
 const R = (window.ArefiBook && window.ArefiBook.roles) ? window.ArefiBook.roles() : {};
 return `<section class="pl-card pl-setup" aria-labelledby="pl-goal-h"><h2 id="pl-goal-h">${E(T('هدف تو', 'Dein Ziel', 'Your goal'))}</h2>
 <fieldset class="pl-roles"><legend>${E(T('برای کدام کار آماده می‌شوی؟', 'Auf welchen Job bereitest du dich vor?', 'Which job are you preparing for?'))}</legend>
 ${Object.keys(R).map(k => `<label class="pl-role"><input type="radio" name="pl-role" id="pl-role-${k}" value="${k}"${st.role === k ? ' checked' : ''}><span>${E(P(R[k]))}</span></label>`).join('')}</fieldset>
 <div class="pl-fields"><p><label for="pl-hours">${E(T('وقت یادگیری در هفته', 'Lernzeit pro Woche', 'Study time per week'))}</label>
 <select id="pl-hours">${HOURS.map(h => `<option value="${h}"${+st.hours === h ? ' selected' : ''}>${E(T(`${num(h)} ساعت`, `${h} Stunden`, `${h} hours`))}</option>`).join('')}</select></p>
 <p><label for="pl-date">${E(T('تاریخ هدف (اختیاری، مثلاً شروع کار یا آزمون)', 'Zieltermin (optional, z. B. Jobstart oder Prüfung)', 'Target date (optional, e.g. job start or exam)'))}</label>
 <input type="date" id="pl-date" value="${E(st.date || '')}"></p></div>
 <p class="pl-hint">${E(T('حدود ۱٫۵ ساعت برای هر ماژول و ۱۰ دقیقه مرور روزانه حساب می‌شود.', 'Gerechnet wird mit etwa 1,5 Stunden pro Modul und 10 Minuten Wiederholung am Tag.', 'The plan assumes about 1.5 hours per module and 10 minutes of review a day.'))}</p>
</section>`;
}

function summaryHtml(st, c) {
 const R = (window.ArefiBook && window.ArefiBook.roles) ? window.ArefiBook.roles() : {};
 const lv = level(c.overall), role = st.role && R[st.role] ? P(R[st.role]) : '';
 const head = role ? T(`آمادگی تو برای ${role}`, `Deine Bereitschaft für ${role}`, `Your readiness for ${role}`) : T('آمادگی کلی تو', 'Deine Bereitschaft insgesamt', 'Your overall readiness');
 let next;
 if (!c.rest.length && c.overall >= 70) next = `<a class="btn" href="#pruefung">${E(T('حالا آزمون پایانی را بده', 'Jetzt die Abschlussprüfung ablegen', 'Take the final exam now'))}</a>`;
 else if (c.rest.length) next = `<a class="btn" href="${E(c.rest[0].href)}">${E(T('ادامه با: ', 'Weiter mit: ', 'Continue with: '))}${E(c.rest[0].t)}</a>`;
 else next = `<a class="btn" href="#wiederholen">${E(T('مرور امروز', 'Heute wiederholen', 'Review today'))}</a>`;
 const weak = c.weakest && c.overall > 0 && c.weakest.r.v < 55 && c.rest.length ? `<p class="pl-weak">${E(T('ضعیف‌ترین مسیر تو:', 'Dein schwächster Lernpfad:', 'Your weakest learning path:'))} <a href="#lernpfad/${c.weakest.no}">${E(T(`مسیر ${num(c.weakest.no)}`, `Lernpfad ${c.weakest.no}`, `Path ${c.weakest.no}`))} – ${E(P(c.weakest.t))}</a> (${E(pc(c.weakest.r.v))})</p>` : '';
 let when;
 if (!c.rest.length) when = T('همهٔ ماژول‌های مسیرهای هدفت انجام شده‌اند.', 'Alle Module deiner Ziel-Lernpfade sind erledigt.', 'All modules of your target learning paths are done.');
 else when = T(`${num(c.rest.length)} ماژول مانده؛ با ${num(c.perWeek)} ماژول در هفته حدود ${num(c.weeks)} هفته – تا ${fmtDate(c.finish)}.`, `Noch ${c.rest.length} Module; mit ${c.perWeek} Modulen pro Woche etwa ${c.weeks} Wochen – bis ${fmtDate(c.finish)}.`, `${c.rest.length} modules left; at ${c.perWeek} modules a week about ${c.weeks} weeks – until ${fmtDate(c.finish)}.`);
 let tg = '';
 if (c.target && c.rest.length) {
  if (c.target.past) tg = T('تاریخ هدف گذشته است؛ یک تاریخ تازه انتخاب کن.', 'Der Zieltermin liegt in der Vergangenheit – wähle einen neuen.', 'The target date has passed – choose a new one.');
  else if (c.target.ok) tg = T(`در برنامه هستی: حدود ${num(c.target.spare)} هفته پیش از ${fmtDate(c.target.d)} تمام می‌کنی.`, `Du liegst im Plan: etwa ${c.target.spare} Wochen vor dem ${fmtDate(c.target.d)} fertig.`, `You are on track: done about ${c.target.spare} weeks before ${fmtDate(c.target.d)}.`);
  else tg = T(`برای رسیدن به ${fmtDate(c.target.d)} حدود ${num(c.target.needH)} ساعت در هفته لازم است – یا تاریخ دیرتری انتخاب کن.`, `Für den ${fmtDate(c.target.d)} brauchst du etwa ${c.target.needH} Stunden pro Woche – oder einen späteren Termin.`, `To make ${fmtDate(c.target.d)} you need about ${c.target.needH} hours a week – or a later date.`);
 }
 return `<section class="pl-card pl-sum pl-${lv[2]}" aria-labelledby="pl-sum-h"><div class="pl-sum-top"><div><h2 id="pl-sum-h">${E(head)}</h2><p class="pl-big">${E(pc(c.overall))} <span>${E(P(lv[1]))}</span></p></div>
 <span class="pl-ring" aria-hidden="true" style="--v:${c.overall}"></span></div>
 <p>${E(when)}</p>${tg ? `<p class="pl-target">${E(tg)}</p>` : ''}${weak}
 <div class="pl-row">${next}</div></section>`;
}

function weekHtml(st, c) {
 if (!c.rest.length) return '';
 const pr = st.role && PRACTICE[st.role];
 const fixed = `<li class="pl-fix"><a href="#wiederholen">${E(T('هر روز حدود ۱۰ دقیقه: مرور امروز', 'Täglich etwa 10 Minuten: Heute wiederholen', 'Every day about 10 minutes: Review today'))}</a></li>${pr ? `<li class="pl-fix"><a href="${pr[0]}">${E(P(pr[1]))}</a></li>` : ''}`;
 const item = m => `<li><a href="${E(m.href)}">${E(m.t)}</a><span>${E(T(`مسیر ${num(m.no)} · `, `Lernpfad ${m.no} · `, `Path ${m.no} · `))}${E(P(m.ch))}</span></li>`;
 const wk = [];
 for (let w = 0; w < 4 && w * c.perWeek < c.rest.length; w++) wk.push(c.rest.slice(w * c.perWeek, (w + 1) * c.perWeek));
 const more = c.rest.length - wk.reduce((n, x) => n + x.length, 0);
 const label = w => w === 0 ? T('این هفته', 'Diese Woche', 'This week') : T(`هفتهٔ ${num(w + 1)}`, `Woche ${w + 1}`, `Week ${w + 1}`);
 return `<section class="pl-week" aria-labelledby="pl-week-h"><h2 id="pl-week-h">${E(T('برنامهٔ هفتگی تو', 'Dein Wochenplan', 'Your weekly plan'))}</h2>
 <p class="pl-sub">${E(T('ترتیب همان ترتیب مسیرهاست؛ هر ماژول را که تمام کنی، برنامه خودش جلو می‌رود.', 'Die Reihenfolge folgt den Lernpfaden; sobald du ein Modul abschließt, rückt der Plan automatisch weiter.', 'The order follows the learning paths; when you finish a module, the plan moves on automatically.'))}</p>
 <ol class="pl-weeks">${wk.map((x, w) => `<li class="pl-wk${w === 0 ? ' is-now' : ''}"><h3>${E(label(w))}</h3><ul>${w === 0 ? fixed : ''}${x.map(item).join('')}</ul></li>`).join('')}</ol>
 ${more > 0 ? `<p class="pl-more">${E(T(`و ${num(more)} ماژول دیگر در هفته‌های بعد.`, `Danach folgen noch ${more} weitere Module.`, `${more} more modules follow after that.`))}</p>` : ''}</section>`;
}

function pathsHtml(st, c) {
 const row = x => {
  const lv = level(x.r.v), parts = [];
  parts.push(T(`ماژول ${num(x.r.mod[0])}/${num(x.r.mod[1])}`, `Module ${x.r.mod[0]}/${x.r.mod[1]}`, `Modules ${x.r.mod[0]}/${x.r.mod[1]}`));
  if (x.r.rev) parts.push(T(`کارت مطمئن ${num(x.r.rev[0])}/${num(x.r.rev[1])}`, `sichere Karten ${x.r.rev[0]}/${x.r.rev[1]}`, `secure cards ${x.r.rev[0]}/${x.r.rev[1]}`));
  if (x.r.hasExam) parts.push(x.r.exam ? T(`آزمون ${num(x.r.exam[0])}/${num(x.r.exam[1])}`, `Prüfung ${x.r.exam[0]}/${x.r.exam[1]}`, `exam ${x.r.exam[0]}/${x.r.exam[1]}`) : T('آزمون: هنوز نه', 'Prüfung: noch nicht', 'exam: not yet'));
  return `<li class="pl-path pl-${lv[2]}${x.mine ? ' is-mine' : ''}"><a href="#lernpfad/${x.no}"><b>${num(x.no)}</b><span class="pl-pt">${E(P(x.t))}${x.mine && st.role ? `<em>${E(T('برای هدف تو', 'für dein Ziel', 'for your goal'))}</em>` : ''}</span></a>
  <span class="pl-val">${E(pc(x.r.v))} · ${E(P(lv[1]))}</span><span class="pl-bar" aria-hidden="true"><i style="width:${x.r.v}%"></i></span><span class="pl-parts">${E(parts.join(' · '))}</span></li>`;
 };
 return `<section class="pl-paths" aria-labelledby="pl-paths-h"><h2 id="pl-paths-h">${E(T('آمادگی در هر مسیر', 'Bereitschaft je Lernpfad', 'Readiness per learning path'))}</h2>
 <p class="pl-sub">${E(T('آمادگی از سه بخش ساخته می‌شود: ماژول‌های انجام‌شده (۵۰٪)، کارت‌هایی که در «مرور امروز» مطمئن شده‌اند (۳۰٪) و آخرین آزمون پایانی (۲۰٪).', 'Die Bereitschaft setzt sich zusammen aus erledigten Modulen (50 %), sicheren Karten in „Heute wiederholen“ (30 %) und der letzten Abschlussprüfung (20 %).', 'Readiness combines completed modules (50 %), secure cards in “Review today” (30 %) and your last final exam (20 %).'))}</p>
 <ol class="pl-list">${c.rows.map(row).join('')}</ol></section>`;
}

function title() { return T('برنامهٔ یادگیری من', 'Mein Lernplan', 'My learning plan'); }
function page() {
 const st = load(), c = compute(st);
 return `<div class="pl" id="pl-root">
 <header class="pl-head"><p class="pl-kicker">${E(T('شخصی', 'Persönlich', 'Personal'))}</p><h1 tabindex="-1">${E(title())}</h1>
 <p class="pl-lead">${E(T('هدف و وقتت را بگو؛ برنامه می‌گوید این هفته چه بخوانی، در هر مسیر چقدر آماده‌ای و کی تمام می‌کنی.', 'Sag uns Ziel und Zeit – der Plan zeigt, was du diese Woche lernst, wie bereit du je Lernpfad bist und wann du fertig bist.', 'Tell it your goal and time – the plan shows what to learn this week, how ready you are per path and when you will be done.'))}</p></header>
 ${setupHtml(st)}<div id="pl-live" class="visually-hidden" aria-live="polite"></div>
 ${summaryHtml(st, c)}${weekHtml(st, c)}${pathsHtml(st, c)}
 <p class="pl-note">${E(T('همه‌چیز فقط در همین مرورگر ذخیره می‌شود.', 'Alles wird nur in diesem Browser gespeichert.', 'Everything is stored only in this browser.'))}</p>
</div>`;
}
function draw(focusId) {
 const r = document.querySelector('#pl-root'); if (!r) return;
 r.outerHTML = page();
 const f = focusId && document.getElementById(focusId); if (f) f.focus({ preventScroll: true });
 const live = document.querySelector('#pl-live'); if (live) setTimeout(() => { live.textContent = T('برنامه به‌روز شد.', 'Plan aktualisiert.', 'Plan updated.'); }, 50);
}
let wired = false;
function mount() {
 if (wired) return; wired = true;
 document.addEventListener('change', e => {
  const t = e.target; if (!t.closest || !t.closest('#pl-root')) return;
  const st = load();
  if (t.name === 'pl-role') st.role = t.value;
  else if (t.id === 'pl-hours') st.hours = +t.value || 6;
  else if (t.id === 'pl-date') st.date = /^\d{4}-\d{2}-\d{2}$/.test(t.value) ? t.value : '';
  else return;
  save(st); draw(t.id);
 });
}
window.ArefiExt = window.ArefiExt || {};
window.ArefiExt.lernplan = { page: () => page(), title, mount: () => { mount(); const h = document.querySelector('#pl-root h1'); if (h && document.activeElement === document.body) h.focus({ preventScroll: true }); } };
window.ArefiPlan = { load, compute };
})();
