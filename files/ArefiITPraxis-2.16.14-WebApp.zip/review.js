/* Arefi ITPraxis – „Heute wiederholen“: tägliche Wiederholung mit verteiltem Lernen (Leitner-Kästen).
   Fragen kommen aus den Wissenschecks aller Lernpfade; falsch beantwortete Prüfungsfragen landen automatisch im Stapel.
   Alles bleibt lokal im Browser (localStorage), kein Konto, kein Server. */
(() => {
'use strict';
const KEY = 'arefi-review';
const INT = [0, 1, 3, 7, 16, 35];          // Tage bis zur nächsten Wiederholung je Kasten
const SESSION = 10, NEW_MAX = 5, ACTIVE = 5; // Karten je Runde, neue Karten je Runde, Antworten für einen „aktiven Tag“
const I = () => ({ fa: 0, de: 1, en: 2 })[document.documentElement.lang] ?? 0;
const T = (fa, de, en) => [fa, de, en][I()];
const P = a => Array.isArray(a) ? a[I()] : a;
const E = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const num = v => I() === 0 ? String(v).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]) : String(v);
const pad = n => String(n).padStart(2, '0');
const dstr = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const today = () => dstr(new Date());
const dayN = s => Math.round(new Date(s + 'T12:00:00').getTime() / 864e5);
const addDays = (s, n) => { const d = new Date(s + 'T12:00:00'); d.setDate(d.getDate() + n); return dstr(d); };
function load() { try { const s = JSON.parse(localStorage.getItem(KEY) || '{}'); return Object.assign({ cards: {}, days: {}, goal: 5 }, s && typeof s === 'object' ? s : {}); } catch { return { cards: {}, days: {}, goal: 5 }; } }
function save(st) { try { localStorage.setItem(KEY, JSON.stringify(st)); } catch { /* Speicher voll oder gesperrt */ } }

/* Fragenpool: alle Wissenscheck-Fragen der Lernpfade, mit Lernpfad und Modul-Link */
let POOL = null, MAP = null;
function pool() {
 if (POOL && POOL.length) return POOL;
 const B = window.ArefiBook;
 POOL = B && B.reviewPool ? B.reviewPool() : [];
 MAP = new Map(POOL.map(q => [q.id, q]));
 return POOL;
}
const qById = id => { pool(); return (MAP && MAP.get(id)) || null; };

function isDue(c, t) { return c && dayN(c.due) <= dayN(t); }
function dueCount(st) { const t = today(); pool(); return Object.keys(st.cards).filter(id => MAP.has(id) && isDue(st.cards[id], t)).length; }
function activeDay(st, d) { return (st.days[d] || 0) >= ACTIVE; }
function streak(st) {
 let d = today(), n = 0;
 if (!activeDay(st, d)) d = addDays(d, -1);
 while (activeDay(st, d)) { n++; d = addDays(d, -1); }
 return n;
}
function weekDays(st) {
 const now = new Date(), wd = (now.getDay() + 6) % 7; let n = 0;
 for (let k = 0; k <= wd; k++) if (activeDay(st, addDays(today(), -k))) n++;
 return n;
}
function newSession(st, extra) {
 const t = today(), ps = pool();
 const due = ps.filter(q => isDue(st.cards[q.id], t)).sort((a, b) => dayN(st.cards[a.id].due) - dayN(st.cards[b.id].due) || st.cards[a.id].b - st.cards[b.id].b);
 const fresh = ps.filter(q => !st.cards[q.id]);
 const learned = fresh.filter(q => q.done), rest = fresh.filter(q => !q.done);
 const nNew = Math.max(0, Math.min(NEW_MAX + (extra ? 5 : 0), SESSION - due.length));
 const pick = due.slice(0, SESSION).concat(learned.slice(0, nNew)).concat(rest.slice(0, Math.max(0, nNew - learned.length)));
 const ids = pick.slice(0, extra ? 5 : SESSION).map(q => q.id);
 st.sess = { date: t, ids, i: 0, right: 0, ans: null, order: ids.map(id => shuffle((qById(id).opts || []).map((_, j) => j), id)) };
 return st;
}
function shuffle(a, seed) { let h = 0; for (const ch of String(seed) + today()) h = (h * 31 + ch.charCodeAt(0)) >>> 0; for (let i = a.length - 1; i > 0; i--) { h = (h * 1103515245 + 12345) >>> 0; const j = h % (i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; }
function grade(st, id, right) {
 const t = today(), c = st.cards[id] || { b: 0, n: 0, ok: 0 };
 c.n++; if (right) { c.ok++; c.b = Math.min(c.b + 1, INT.length - 1); } else c.b = 1;
 c.due = addDays(t, right ? INT[c.b] : 1); c.last = t;
 st.cards[id] = c; st.days[t] = (st.days[t] || 0) + 1;
 const keys = Object.keys(st.days).sort(); if (keys.length > 400) keys.slice(0, keys.length - 400).forEach(k => delete st.days[k]);
}
/* Schnittstelle für andere Teile: falsche Prüfungsantworten wiederholen */
function addWrong(ids) {
 const st = load(), t = today(); pool();
 (ids || []).forEach(id => { if (!MAP.has(id)) return; const c = st.cards[id] || { b: 0, n: 0, ok: 0 }; c.b = 1; c.due = t; st.cards[id] = c; });
 save(st);
}
function summary() { const st = load(); pool(); return { due: dueCount(st), streak: streak(st), week: weekDays(st), goal: st.goal || 5, total: POOL.length, known: Object.keys(st.cards).length, todayN: st.days[today()] || 0 }; }

/* ---------- Ansicht ---------- */
const title = () => T('مرور امروز', 'Heute wiederholen', 'Review today');
function statsHtml(st) {
 const s = streak(st), w = weekDays(st), g = st.goal || 5, d = dueCount(st);
 const goalSel = [3, 5, 7].map(n => `<option value="${n}"${n === g ? ' selected' : ''}>${num(n)}</option>`).join('');
 return `<ul class="rv-stats">
  <li><b>${num(d)}</b><span>${E(T('کارت برای امروز', 'Karten fällig', 'cards due'))}</span></li>
  <li><b>${num(s)}</b><span>${E(T('روز پشت سر هم', 'Tage in Folge', 'days in a row'))}</span></li>
  <li><b>${num(w)}/${num(g)}</b><span><label for="rv-goal">${E(T('هدف این هفته (روز)', 'Wochenziel (Tage)', 'Weekly goal (days)'))}</label> <select id="rv-goal">${goalSel}</select></span></li>
 </ul>`;
}
function cardHtml(st) {
 const s = st.sess, id = s.ids[s.i], q = qById(id);
 if (!q) { s.i++; save(st); return s.i < s.ids.length ? cardHtml(st) : doneHtml(st); }
 const ord = s.order[s.i] || q.opts.map((_, j) => j), ans = s.ans;
 const opts = ord.map((j, k) => {
  const cls = ans == null ? '' : j === q.ok ? ' is-ok' : j === ans ? ' is-bad' : '';
  return `<label class="rv-opt${cls}"><input type="radio" name="rv-q" value="${j}"${ans != null ? ' disabled' : ''}${ans === j ? ' checked' : ''}> <span>${E(P(q.opts[j]))}</span></label>`;
 }).join('');
 const fb = ans == null ? '' : ans === q.ok
  ? `<p class="rv-fb is-ok">✓ ${E(T('درست است.', 'Richtig.', 'Correct.'))} ${E(T('این کارت دیرتر دوباره می‌آید.', 'Diese Karte kommt später wieder.', 'This card comes back later.'))}</p>`
  : `<p class="rv-fb is-bad">✗ ${E(T('هنوز نه. پاسخ درست سبز شده است. این کارت فردا دوباره می‌آید.', 'Noch nicht. Die richtige Antwort ist grün markiert. Diese Karte kommt morgen wieder.', 'Not yet. The correct answer is marked green. This card comes back tomorrow.'))} <a href="${E(q.href)}">${E(T('درس مربوط را باز کن', 'Lektion dazu öffnen', 'Open the lesson'))}</a></p>`;
 return `<div class="rv-card">
  <p class="rv-pos">${E(T('کارت', 'Karte', 'Card'))} ${num(s.i + 1)} ${E(T('از', 'von', 'of'))} ${num(s.ids.length)} · <a href="#lernpfad/${q.no}">${E(T('مسیر', 'Lernpfad', 'Path'))} ${num(q.no)}</a> · ${E(P(q.mt))}</p>
  <span class="rv-bar" role="img" aria-label="${num(Math.round(100 * s.i / s.ids.length))}%"><i style="width:${Math.round(100 * s.i / s.ids.length)}%"></i></span>
  <fieldset><legend>${E(P(q.q))}</legend>${opts}</fieldset>
  <div aria-live="polite">${fb}</div>
  <div class="rv-row">${ans == null ? `<button type="button" class="btn" data-rv="check">${E(T('بررسی پاسخ', 'Antwort prüfen', 'Check answer'))}</button>` : `<button type="button" class="btn" data-rv="next">${E(s.i + 1 < s.ids.length ? T('کارت بعدی', 'Nächste Karte', 'Next card') : T('پایان این دور', 'Runde beenden', 'Finish round'))}</button>`}</div>
 </div>`;
}
function doneHtml(st) {
 const s = st.sess, d = dueCount(st), tm = Object.values(st.cards).filter(c => dayN(c.due) === dayN(today()) + 1).length;
 return `<div class="rv-card rv-done">
  <h2 tabindex="-1">${E(T('این دور تمام شد', 'Runde geschafft', 'Round complete'))}</h2>
  <p>${E(T(`${num(s.right)} از ${num(s.ids.length)} پاسخ درست.`, `${s.right} von ${s.ids.length} Antworten richtig.`, `${s.right} of ${s.ids.length} answers correct.`))} ${E(T(`فردا ${num(tm)} کارت منتظر توست.`, `Morgen warten ${tm} Karten auf dich.`, `${tm} cards are waiting for you tomorrow.`))}</p>
  <div class="rv-row">${d ? `<button type="button" class="btn" data-rv="start">${E(T('کارت‌های باقی‌ماندهٔ امروز', 'Restliche Karten von heute', 'Remaining cards for today'))}</button>` : `<button type="button" class="btn secondary" data-rv="extra">${E(T('۵ کارت تازهٔ دیگر', '5 weitere neue Karten', '5 more new cards'))}</button>`}<a class="btn secondary" href="#inhalt">${E(T('برگشت به مسیرها', 'Zurück zu den Lernpfaden', 'Back to the learning paths'))}</a></div>
 </div>`;
}
function page() {
 const st = load(), ps = pool();
 let body;
 if (!ps.length) body = `<p class="card">${E(T('پرسش‌های دوره‌ها هنوز بارگذاری نشده‌اند. صفحه را دوباره باز کن.', 'Die Kursfragen sind noch nicht geladen. Bitte die Seite neu öffnen.', 'Course questions are not loaded yet. Please reopen the page.'))}</p>`;
 else if (st.sess && st.sess.date === today() && st.sess.i < st.sess.ids.length) body = cardHtml(st);
 else if (st.sess && st.sess.date === today() && st.sess.ids.length) body = doneHtml(st);
 else {
  const d = dueCount(st), probe = newSession(JSON.parse(JSON.stringify(st)), false).sess.ids.length;
  body = `<div class="rv-card rv-start"><p>${E(d ? T(`امروز ${num(d)} کارت برای مرور داری، به‌علاوهٔ چند کارت تازه از فصل‌هایی که خوانده‌ای.`, `Heute sind ${d} Karten fällig, dazu ein paar neue Karten aus Kapiteln, die du schon bearbeitet hast.`, `${d} cards are due today, plus a few new cards from chapters you have already worked on.`) : T('امروز کارت عقب‌افتاده‌ای نداری. با چند کارت تازه شروع کن.', 'Heute ist nichts überfällig. Starte mit ein paar neuen Karten.', 'Nothing is overdue today. Start with a few new cards.'))}</p>
  <button type="button" class="btn" data-rv="start"${probe ? '' : ' disabled'}>${E(T(`شروع با ${num(probe)} کارت (حدود ۱۰ دقیقه)`, `Mit ${probe} Karten starten (ca. 10 Minuten)`, `Start with ${probe} cards (about 10 minutes)`))}</button></div>`;
 }
 return `<div class="rv" id="rv-root">
 <header class="rv-head"><p class="rv-kicker">${E(T('تمرین روزانه', 'Tägliche Übung', 'Daily practice'))}</p><h1 tabindex="-1">${E(title())}</h1>
 <p class="rv-lead">${E(T('هر روز چند دقیقه: پرسش‌ها از همهٔ مسیرها می‌آیند و هر کارت درست‌شده دیرتر برمی‌گردد – ۱، ۳، ۷، ۱۶ و ۳۵ روز بعد. اشتباه‌ها فردا دوباره می‌آیند. پاسخ‌های اشتباه آزمون پایانی هم خودکار اینجا اضافه می‌شوند.', 'Jeden Tag ein paar Minuten: Die Fragen kommen aus allen Lernpfaden, jede richtig beantwortete Karte kommt später wieder – nach 1, 3, 7, 16 und 35 Tagen. Fehler kommen morgen erneut. Falsche Antworten aus der Abschlussprüfung landen automatisch hier.', 'A few minutes every day: questions come from all learning paths, every correct card returns later – after 1, 3, 7, 16 and 35 days. Mistakes come back tomorrow. Wrong answers from the final exam are added here automatically.'))}</p></header>
 ${statsHtml(st)}${body}
 <p class="rv-note">${E(T('همه‌چیز فقط در همین مرورگر ذخیره می‌شود.', 'Alles wird nur in diesem Browser gespeichert.', 'Everything is stored only in this browser.'))}</p></div>`;
}
function draw(focusSel) { const r = document.querySelector('#rv-root'); if (!r) return; r.outerHTML = page(); mount(); const f = focusSel && document.querySelector(focusSel); if (f) f.focus({ preventScroll: false }); }
let wired = false;
function mount() {
 if (wired) return; wired = true;
 document.addEventListener('click', e => {
  const b = e.target.closest('#rv-root [data-rv]'); if (!b) return;
  const k = b.dataset.rv, st = load();
  if (k === 'start' || k === 'extra') { newSession(st, k === 'extra'); save(st); draw('#rv-root legend'); }
  else if (k === 'check') {
   const c = document.querySelector('#rv-root input[name="rv-q"]:checked');
   if (!c) { const fs = document.querySelector('#rv-root fieldset'); if (fs) fs.classList.add('is-empty'); return; }
   const s = st.sess, id = s.ids[s.i], q = qById(id), a = +c.value, right = a === q.ok;
   s.ans = a; if (right) s.right++; grade(st, id, right); save(st); draw('#rv-root [data-rv="next"]');
  } else if (k === 'next') { const s = st.sess; s.i++; s.ans = null; save(st); draw(s.i < s.ids.length ? '#rv-root legend' : '#rv-root h2'); }
 });
 document.addEventListener('change', e => { if (e.target.id !== 'rv-goal') return; const st = load(); st.goal = +e.target.value || 5; save(st); draw('#rv-goal'); });
}
window.ArefiExt = window.ArefiExt || {};
window.ArefiExt.wiederholen = { page: () => page(), title, mount: () => { mount(); const h = document.querySelector('#rv-root legend') || document.querySelector('#rv-root h1'); if (h && document.activeElement === document.body) { if (!h.hasAttribute('tabindex')) h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); } } };
/* Stand je Lernpfad für „Mein Lernplan“: gesehene und sichere Karten (Kasten 2 oder höher) */
function byPath() { const st = load(), out = {}; pool().forEach(q => { const o = out[q.no] || (out[q.no] = { total: 0, seen: 0, firm: 0 }); o.total++; const c = st.cards[q.id]; if (c && c.n) { o.seen++; if (c.b >= 2) o.firm++; } }); return out; }
window.ArefiReview = { addWrong, summary, byPath };
})();
