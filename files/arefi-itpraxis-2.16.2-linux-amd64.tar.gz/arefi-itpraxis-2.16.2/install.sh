#!/bin/sh
# Arefi ITPraxis fuer den aktuellen Benutzer installieren (ohne root)
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.local/opt/arefi-itpraxis"
mkdir -p "$DEST" "$HOME/.local/bin" "$HOME/.local/share/applications" "$HOME/.local/share/icons/hicolor/256x256/apps"
cp "$DIR/arefi-itpraxis" "$DEST/arefi-itpraxis" && chmod 755 "$DEST/arefi-itpraxis"
ln -sf "$DEST/arefi-itpraxis" "$HOME/.local/bin/arefi-itpraxis"
cp "$DIR/arefi-itpraxis.png" "$HOME/.local/share/icons/hicolor/256x256/apps/arefi-itpraxis.png"
sed "s#/opt/arefi-itpraxis/arefi-itpraxis#$DEST/arefi-itpraxis#" "$DIR/arefi-itpraxis.desktop" > "$HOME/.local/share/applications/arefi-itpraxis.desktop"
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database -q "$HOME/.local/share/applications" || true
echo "Arefi ITPraxis installiert. Start: Anwendungsmenue oder 'arefi-itpraxis'."
