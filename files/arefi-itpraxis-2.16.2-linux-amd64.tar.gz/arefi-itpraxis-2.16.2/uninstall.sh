#!/bin/sh
rm -rf "$HOME/.local/opt/arefi-itpraxis" "$HOME/.local/bin/arefi-itpraxis" "$HOME/.local/share/applications/arefi-itpraxis.desktop" "$HOME/.local/share/icons/hicolor/256x256/apps/arefi-itpraxis.png"
echo "Arefi ITPraxis entfernt. Lernfortschritt liegt weiter in ~/.config/ArefiITPraxis (selbst loeschen, falls gewuenscht)."
