/* Arefi ITPraxis – gemeinsame Ansicht für Lernstrecken (Windows Server, Linux-Server). */
window.ArefiCourseView = function (C, cfg) {
'use strict';
const KEY = cfg.key;
const L = () => (window.ServerLabApp ? window.ServerLabApp.locale() : 'fa');
const I = () => ({ fa: 0, de: 1, en: 2 }[L()]);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = n => L() === 'fa' ? String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]) : String(n);
const load = () => { try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch { return {}; } };
const save = v => { try { localStorage.setItem(KEY, JSON.stringify(v)); } catch {} };
const st = id => { const a = load()[id] || {}; return { c: Array.isArray(a.c) ? a.c : [], page: a.page || '', note: a.note || '' }; };
const done = m => { const s = st(m.id); return m.lab.checks[0].every((_, k) => s.c[k]); };
const prog = m => { const s = st(m.id); return m.lab.checks[0].filter((_, k) => s.c[k]).length; };

const TX = {
  fa: { title: 'دورهٔ جامع Windows Server 2025', lead: 'این دوره بر اساس موضوع‌های کتاب «Windows Server 2025 – Das umfassende Handbuch» (Rheinwerk) مرتب شده است. توضیح‌ها، تمرین‌ها و پرسش‌ها نوشتهٔ خود این برنامه‌اند و بر پایهٔ مستندات رسمی Microsoft؛ متن کتاب در برنامه نیست. هنگام خواندن کتاب، شمارهٔ صفحه و یادداشتت را در هر ماژول ثبت کن.', overall: 'پیشرفت دوره', of: 'از', modules: 'ماژول', part: ['بخش ۱: پایه و هویت', 'بخش ۲: هویت، سیاست و سرویس‌های شبکه', 'بخش ۳: فایل، گواهی، مجازی‌سازی و وب', 'بخش ۴: بهره‌برداری، دسترسی، ابر و امنیت'], module: 'ماژول', doneTag: 'انجام شد', bookTag: 'صفحهٔ کتاب', why: 'چرا در کار مهم است', know: 'دانش اصلی', lab: 'تمرین عملی در آزمایشگاه', vm: 'ماشین', steps: 'مراحل', solution: 'نمایش فرمان‌ها (اول خودت امتحان کن)', copy: 'کپی فرمان', criteria: 'معیارهای موفقیت', criteriaSub: 'فقط بعد از دیدن نتیجهٔ واقعی تیک بزن.', allDone: 'این ماژول کامل شد.', pitfalls: 'اشتباه‌های رایج در کار', iv: 'پرسش‌های مصاحبهٔ کاری', answer: 'پاسخ نمونه', book: 'کتاب و یادداشت من', bookPage: 'صفحه در کتاب', bookPh: 'مثلاً ۲۱۴–۲۳۰', note: 'یادداشت من (خودکار ذخیره می‌شود)', notePh: 'نکته‌های مهم از کتاب و آزمایشگاه به زبان خودت؛ گذرواژه ننویس.', saved: 'ذخیره شد', sources: 'منابع رسمی', back: 'همهٔ ماژول‌ها', prev: 'ماژول قبلی', next: 'ماژول بعدی', storage: 'پیشرفت و یادداشت‌های این دوره در همین مرورگر ذخیره می‌شوند.', start: 'شروع کن', cont: 'ادامه بده' },
  de: { title: 'Lernstrecke Windows Server 2025', lead: 'Diese Lernstrecke folgt den Themen des Buchs „Windows Server 2025 – Das umfassende Handbuch“ (Rheinwerk). Erklärungen, Übungen und Fragen sind eigene Inhalte dieses Programms auf Basis der offiziellen Microsoft-Dokumentation; Buchtext ist nicht enthalten. Trage beim Lesen in jedem Modul die Buchseite und deine Notizen ein.', overall: 'Fortschritt der Lernstrecke', of: 'von', modules: 'Modulen', part: ['Teil 1: Grundlagen und Identität', 'Teil 2: Identität, Richtlinien und Netzdienste', 'Teil 3: Dateien, Zertifikate, Virtualisierung und Web', 'Teil 4: Betrieb, Zugriff, Cloud und Sicherheit'], module: 'Modul', doneTag: 'erledigt', bookTag: 'Buchseite', why: 'Warum das im Job zählt', know: 'Kernwissen', lab: 'Praxisübung im Labor', vm: 'Maschine', steps: 'Arbeitsschritte', solution: 'Befehle anzeigen (erst selbst versuchen)', copy: 'Kopieren', criteria: 'Erfolgskriterien', criteriaSub: 'Erst abhaken, wenn du das echte Ergebnis gesehen hast.', allDone: 'Modul abgeschlossen.', pitfalls: 'Typische Fehler im Alltag', iv: 'Fragen aus Vorstellungsgesprächen', answer: 'Musterantwort', book: 'Buch und meine Notizen', bookPage: 'Seiten im Buch', bookPh: 'z. B. 214–230', note: 'Meine Notiz (wird automatisch gespeichert)', notePh: 'Wichtiges aus Buch und Labor in eigenen Worten – keine Kennwörter.', saved: 'Gespeichert', sources: 'Offizielle Quellen', back: 'Alle Module', prev: 'Vorheriges Modul', next: 'Nächstes Modul', storage: 'Fortschritt und Notizen dieser Lernstrecke werden in diesem Browser gespeichert.', start: 'Starten', cont: 'Weitermachen' },
  en: { title: 'Windows Server 2025 course', lead: 'This course follows the topics of the book “Windows Server 2025 – Das umfassende Handbuch” (Rheinwerk). Explanations, exercises and questions are this app’s own content based on official Microsoft documentation; no book text is included. While reading, record the book pages and your notes in each module.', overall: 'Course progress', of: 'of', modules: 'modules', part: ['Part 1: Foundations and identity', 'Part 2: Identity, policy and network services', 'Part 3: Files, certificates, virtualization and web', 'Part 4: Operations, access, cloud and security'], module: 'Module', doneTag: 'done', bookTag: 'Book pages', why: 'Why it matters on the job', know: 'Core knowledge', lab: 'Hands-on lab exercise', vm: 'Machine', steps: 'Steps', solution: 'Show commands (try it yourself first)', copy: 'Copy', criteria: 'Success criteria', criteriaSub: 'Tick only after seeing the real result.', allDone: 'Module complete.', pitfalls: 'Common mistakes at work', iv: 'Job interview questions', answer: 'Sample answer', book: 'Book and my notes', bookPage: 'Pages in the book', bookPh: 'e.g. 214–230', note: 'My note (saved automatically)', notePh: 'Key points from book and lab in your own words – no passwords.', saved: 'Saved', sources: 'Official sources', back: 'All modules', prev: 'Previous module', next: 'Next module', storage: 'Progress and notes for this course are stored in this browser.', start: 'Start', cont: 'Continue' }
};
Object.keys(TX).forEach(l => Object.assign(TX[l], (cfg.texts || {})[l] || {}));
const T = () => TX[L()];

function overview() {
  const t = T(), M = C.modules, n = M.filter(done).length;
  const next = M.find(m => !done(m)) || M[0];
  const parts = [1, 2, 3, 4].map(p => `<section class="wsc-part"><h2>${esc(t.part[p - 1])}</h2><ol class="wsc-list">${M.map((m, k) => [m, k]).filter(([m]) => m.part === p).map(([m, k]) => {
    const s = st(m.id), pr = prog(m), tot = m.lab.checks[0].length;
    return `<li><a class="wsc-card${done(m) ? ' is-done' : ''}" href="#${cfg.hash}/${m.id}"><span class="wsc-no">${done(m) ? '✓' : num(k + 1)}</span><span class="wsc-ct"><b>${esc(m.title[I()])}</b><small>${esc(m.goal[I()])}</small><span class="wsc-meta"><span class="wsc-bar"><span style="width:${Math.round(pr / tot * 100)}%"></span></span>${num(pr)} ${esc(t.of)} ${num(tot)}${s.page ? ` · ${esc(t.bookTag)} ${esc(s.page)}` : ''}</span></span></a></li>`;
  }).join('')}</ol></section>`).join('');
  return `<div class="wsc"><header class="wsc-head"><h1>${esc(t.title)}</h1><p>${esc(t.lead)}</p>
<div class="wsc-overall"><div><b>${num(n)} ${esc(t.of)} ${num(M.length)}</b> <span>${esc(t.modules)}</span></div><span class="wsc-bar wsc-bar-lg"><span style="width:${Math.round(n / M.length * 100)}%"></span></span><a class="btn" href="#${cfg.hash}/${next.id}">${esc(n ? t.cont : t.start)}: ${esc(next.title[I()])}</a></div>
<p class="micro">${esc(t.storage)}</p></header>${parts}</div>`;
}

function moduleView(id) {
  const t = T(), i = I(), M = C.modules, k = M.findIndex(m => m.id === id);
  if (k < 0) return overview();
  const m = M[k], s = st(m.id), tot = m.lab.checks[0].length, pr = prog(m);
  const prev = M[k - 1], next = M[k + 1];
  return `<div class="wsc wsc-mod" data-wsc="${m.id}">
<div class="crumb"><a href="#${cfg.hash}">${esc(t.title)}</a><span>/</span><span>${esc(t.module)} ${num(k + 1)} ${esc(t.of)} ${num(M.length)}</span></div>
<header class="wsc-head"><p class="wsc-partname">${esc(t.part[m.part - 1])}</p><h1>${esc(m.title[i])}</h1><p class="wsc-goal">${esc(m.goal[i])}</p></header>
<div class="wsc-grid"><div class="wsc-main">
<section class="card wsc-sec"><h2>${esc(t.why)}</h2><p>${esc(m.why[i])}</p></section>
<section class="card wsc-sec"><h2>${esc(t.know)}</h2><ul class="wsc-know">${m.know.map(x => `<li>${esc(x[i])}</li>`).join('')}</ul></section>
<section class="card wsc-sec wsc-lab"><h2>${esc(t.lab)}</h2><p class="wsc-vm"><b>${esc(t.vm)}:</b> <bdi dir="ltr">${esc(m.lab.vm)}</bdi></p>
<h3>${esc(t.steps)}</h3><ol>${m.lab.steps[i].map(x => `<li>${esc(x)}</li>`).join('')}</ol>
<details class="wsc-sol"><summary>${esc(t.solution)}</summary><div class="command"><div class="command-head"><span>${esc(m.lab.shell || cfg.shell || "PowerShell")}</span><button type="button" class="copy-btn" data-action="copy">${esc(t.copy)}</button></div><pre dir="ltr"><code>${esc(m.lab.code)}</code></pre></div></details>
<h3>${esc(t.criteria)} <span class="wsc-count" id="wsc-count">${num(pr)} ${esc(t.of)} ${num(tot)}</span></h3><p class="micro">${esc(t.criteriaSub)}</p>
${m.lab.checks[i].map((c, j) => `<label class="wsc-check"><input type="checkbox" data-wsc-check="${j}" ${s.c[j] ? 'checked' : ''}><span>${esc(c)}</span></label>`).join('')}
<p class="wsc-done" id="wsc-done" role="status"${pr === tot ? '' : ' hidden'}>${esc(t.allDone)}</p></section>
<section class="card wsc-sec"><h2>${esc(t.pitfalls)}</h2><ul class="wsc-pit">${m.pitfalls.map(x => `<li>${esc(x[i])}</li>`).join('')}</ul></section>
<section class="card wsc-sec"><h2>${esc(t.iv)}</h2>${m.iv.map(q => `<details class="wsc-iv"><summary>${esc(q[0][i])}</summary><p><b>${esc(t.answer)}:</b> ${esc(q[1][i])}</p></details>`).join('')}</section>
<nav class="wsc-nav">${prev ? `<a class="btn secondary" href="#${cfg.hash}/${prev.id}">${esc(t.prev)}</a>` : '<span></span>'}<a class="btn secondary" href="#${cfg.hash}">${esc(t.back)}</a>${next ? `<a class="btn" href="#${cfg.hash}/${next.id}">${esc(t.next)}</a>` : '<span></span>'}</nav>
</div><aside class="wsc-aside">
<section class="card wsc-sec"><h2>${esc(t.book)}</h2><label class="note-label" for="wsc-page">${esc(t.bookPage)}</label><input id="wsc-page" class="wsc-input" maxlength="40" value="${esc(s.page)}" placeholder="${esc(t.bookPh)}">
<label class="note-label" for="wsc-note">${esc(t.note)}</label><textarea id="wsc-note" maxlength="8000" placeholder="${esc(t.notePh)}">${esc(s.note)}</textarea><p class="micro" id="wsc-saved" role="status"></p></section>
<section class="card wsc-sec"><h2>${esc(t.sources)}</h2><ul class="wsc-src">${m.sources.map(([n, u]) => `<li><a href="${esc(u)}" target="_blank" rel="noopener noreferrer" dir="ltr">${esc(n)} ↗</a></li>`).join('')}</ul></section>
</aside></div></div>`;
}

C.page = id => (id ? moduleView(id) : overview());
C.mount = () => {
  const root = document.querySelector('.wsc-mod');
  if (!root) return;
  const id = root.dataset.wsc, m = C.modules.find(x => x.id === id), t = T();
  const upd = fn => { const all = load(); const cur = all[id] || {}; fn(cur); all[id] = cur; save(all); };
  root.addEventListener('change', e => {
    const cb = e.target.closest('[data-wsc-check]');
    if (!cb) return;
    upd(cur => { cur.c = Array.isArray(cur.c) ? cur.c : []; cur.c[+cb.dataset.wscCheck] = cb.checked; });
    const pr = prog(m), tot = m.lab.checks[0].length;
    document.getElementById('wsc-count').textContent = `${num(pr)} ${t.of} ${num(tot)}`;
    document.getElementById('wsc-done').hidden = pr < tot;
  });
  let timer;
  const savedMsg = () => { const el = document.getElementById('wsc-saved'); if (el) { el.textContent = t.saved; clearTimeout(timer); timer = setTimeout(() => { el.textContent = ''; }, 1500); } };
  root.querySelector('#wsc-page').addEventListener('input', e => { upd(cur => { cur.page = e.target.value.slice(0, 40); }); savedMsg(); });
  root.querySelector('#wsc-note').addEventListener('input', e => { upd(cur => { cur.note = e.target.value.slice(0, 8000); }); savedMsg(); });
};
return { page: C.page, mount: C.mount };
};
