/* Arefi ITPraxis – eigene Abschlussprüfung: Teil A Wissen (Fragen aus allen Lernpfaden, Zeitlimit),
   Teil B Praxis (drei Tickets im Ticketsystem-Simulator), Ergebnis und druckbarer Lernnachweis mit Logo.
   Kein staatliches oder herstellerbezogenes Zertifikat. Adresse: #pruefung. Speicher: localStorage 'arefi-exam'. */
(() => {
'use strict';
const KEY = 'arefi-exam', PER_PATH = 5, MINUTES = 45, PASS_A = 70, PASS_B = 60, N_TICKETS = 3;
const lang = () => { const l = document.documentElement.lang; return l === 'de' || l === 'en' ? l : 'fa'; };
const I = () => ({ fa: 0, de: 1, en: 2 })[lang()];
const T = (fa, de, en) => ({ fa, de, en })[lang()];
const P = a => Array.isArray(a) ? a[I()] : a;
const E = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = n => lang() === 'fa' ? String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]) : String(n);
const pc = n => lang() === 'fa' ? num(n) + '٪' : n + ' %';
const load = () => { try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch { return {}; } };
const save = v => { try { localStorage.setItem(KEY, JSON.stringify(v)); } catch {} };
const rnd = seed => { let x = seed >>> 0 || 1; return () => { x ^= x << 13; x >>>= 0; x ^= x >>> 17; x ^= x << 5; x >>>= 0; return x / 4294967296; }; };
const shuffle = (a, r) => { a = a.slice(); for (let k = a.length - 1; k > 0; k--) { const j = Math.floor(r() * (k + 1)); [a[k], a[j]] = [a[j], a[k]]; } return a; };
let PS = null, QM = null;
const paths = () => { if (PS && PS.length) return PS; PS = (window.ArefiBook && window.ArefiBook.examPaths) ? window.ArefiBook.examPaths().filter(p => p.qs.length) : []; QM = new Map(); PS.forEach(p => p.qs.forEach(q => QM.set(q.id, q))); return PS; };
const total = () => paths().reduce((a, p) => a + Math.min(PER_PATH, p.qs.length), 0);
const desk = () => { try { return window.ArefiWork.ws().desk || {}; } catch { return {}; } };
const tickets = () => (window.ArefiTicketDesk && window.ArefiTicketDesk.tickets) || [];
const tTitle = id => { const c = (window.LAB && window.LAB.workCases || []).find(x => x.id === id); return c ? ((c[lang()] || c.de || {}).t || id) : id; };
let timer = null;

/* ---------- Ablauf ---------- */
function start(name, extra) {
 const seed = (Date.now() ^ Math.floor(Math.random() * 1e9)) >>> 0, r = rnd(seed), qs = [];
 paths().forEach(p => shuffle(p.qs, r).slice(0, PER_PATH).forEach(q => qs.push({ p: p.no, id: q.id, o: shuffle(q.opts.map((_, k) => k), r) })));
 const tk = shuffle(tickets().map(t => t.id), r).slice(0, N_TICKETS), d = desk();
 const st = load();
 st.name = String(name || '').slice(0, 80);
 st.cur = { seed, start: Date.now(), mins: extra ? Math.round(MINUTES * 1.5) : MINUTES, qs, a: {}, tk, tn: Object.fromEntries(tk.map(id => [id, (d[id] && d[id].n) || 0])), stage: 'a' };
 save(st);
}
function qById(id) { paths(); return (QM && QM.get(id)) || null; }
/* 4: gespeicherter Versuch passt noch zu den aktuellen Inhalten? */
function valid(cur) { return Array.isArray(cur.qs) && cur.qs.length > 0 && cur.qs.every(x => { const q = qById(x.id); return q && paths().some(p => p.no === x.p) && Array.isArray(x.o) && x.o.length === q.opts.length && x.o.every(i => i >= 0 && i < q.opts.length); }); }
function scoreA(cur) {
 const per = {};
 cur.qs.forEach((x, i) => { const q = qById(x.id); if (!q) return; const s = per[x.p] || (per[x.p] = { ok: 0, n: 0 }); s.n++; if (cur.a[i] !== undefined && x.o[cur.a[i]] === q.ok) s.ok++; });
 const ok = Object.values(per).reduce((a, s) => a + s.ok, 0), n = Object.values(per).reduce((a, s) => a + s.n, 0);
 return { ok, n, pct: n ? Math.round(ok / n * 100) : 0, per: Object.keys(per).map(k => +k).sort((a, b) => a - b).map(k => ({ no: k, ok: per[k].ok, n: per[k].n })) };
}
function scoreB(cur) {
 const d = desk();
 const rows = cur.tk.map(id => { const x = d[id]; const done = !!(x && (typeof x.at === 'number' ? x.at >= cur.start : x.n > (cur.tn[id] || 0))); return { id, done, pts: done ? x.last : 0 }; });
 return { rows, pct: rows.length ? Math.round(rows.reduce((a, r) => a + r.pts, 0) / rows.length) : 0, done: rows.filter(r => r.done).length };
}
function submitA() { const st = load(); if (!st.cur || st.cur.stage !== 'a') return; st.cur.resA = scoreA(st.cur);
 try { if (window.ArefiReview) window.ArefiReview.addWrong(st.cur.qs.filter((x, i) => { const q = qById(x.id); return q && !(st.cur.a[i] !== undefined && x.o[st.cur.a[i]] === q.ok); }).map(x => x.id)); } catch (e) { /* Wiederholung ist optional */ } st.cur.endA = Date.now(); st.cur.stage = 'b'; save(st); }
function finish() {
 const st = load(); if (!st.cur || st.cur.stage !== 'b') return;
 const b = scoreB(st.cur), a = st.cur.resA, pass = a.pct >= PASS_A && b.pct >= PASS_B;
 const res = { date: Date.now(), name: st.name || '', mins: st.cur.mins || MINUTES, a: a.pct, aok: a.ok, an: a.n, per: a.per.map(x => ({ no: x.no, ok: x.ok, n: x.n })), b: b.pct, rows: b.rows, pass };
 st.hist = (st.hist || []).concat([res]).slice(-20); st.last = res; delete st.cur; save(st);
}
const left = cur => Math.max(0, (cur.mins || MINUTES) * 60 - Math.floor((Date.now() - cur.start) / 1000));
const mmss = s => num(String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'));

/* ---------- Ansichten ---------- */
function introView(st) {
 const ps = paths(), last = st.last;
 if (!ps.length) return `<p class="card">${E(T('پرسش‌های دوره‌ها هنوز بارگذاری نشده‌اند. صفحه را دوباره باز کن.', 'Die Kursfragen sind noch nicht geladen. Bitte die Seite neu öffnen.', 'Course questions are not loaded yet. Please reopen the page.'))}</p>`;
 const hist = (st.hist || []).slice().reverse().slice(0, 5);
 const loc = { fa: 'fa-IR', de: 'de-DE', en: 'en-GB' }[lang()];
 return `<header class="ex-head">${window.ArefiBrand && window.ArefiBrand.mark ? window.ArefiBrand.mark('ex-mark') : ''}<div><p class="ex-kicker">Arefi ITPraxis</p><h1>${E(T('آزمون پایانی Arefi ITPraxis', 'Abschlussprüfung Arefi ITPraxis', 'Arefi ITPraxis final exam'))}</h1>
<p>${E(T('مثل یک آزمون واقعی نشان بده چه بلدی: بخش الف دانش از همهٔ مسیرهای یادگیری با زمان محدود، بخش ب سه تیکت عملی در شبیه‌ساز. اگر هر دو بخش قبول شود، گواهی یادگیری با لوگوی Arefi ITPraxis می‌گیری.', 'Zeig wie in einer echten Prüfung, was du kannst: Teil A Wissen aus allen Lernpfaden mit Zeitlimit, Teil B drei Praxis-Tickets im Simulator. Bestehst du beide Teile, bekommst du einen Lernnachweis mit dem Logo von Arefi ITPraxis.', 'Show what you can do like in a real exam: part A knowledge from all learning paths with a time limit, part B three practical tickets in the simulator. Pass both parts and you get a certificate of learning with the Arefi ITPraxis logo.'))}</p></div></header>
<section class="ex-parts">
<div class="ex-part"><span class="ex-tag">${E(T('بخش الف', 'Teil A', 'Part A'))}</span><h2>${E(T('دانش', 'Wissen', 'Knowledge'))}</h2><ul>
<li>${E(T(`${num(total())} پرسش چهارگزینه‌ای، از هر مسیر ${num(PER_PATH)} پرسش`, `${total()} Fragen mit einer richtigen Antwort, ${PER_PATH} aus jedem Lernpfad`, `${total()} single-answer questions, ${PER_PATH} from each learning path`))}</li>
<li>${E(T(`زمان: ${num(MINUTES)} دقیقه؛ اگر از صفحه بیرون بروی هم زمان ادامه دارد؛ با پایان زمان، پاسخ‌ها خودکار ثبت می‌شوند`, `Zeit: ${MINUTES} Minuten; die Zeit läuft auch weiter, wenn du die Seite verlässt; danach wird automatisch abgegeben`, `Time: ${MINUTES} minutes; the clock keeps running if you leave the page; answers are submitted automatically when time is up`))}</li>
<li>${E(T(`قبولی: دست‌کم ${num(PASS_A)}٪ پاسخ درست`, `Bestanden ab ${PASS_A} % richtigen Antworten`, `Pass mark: ${PASS_A} % correct`))}</li></ul></div>
<div class="ex-part"><span class="ex-tag">${E(T('بخش ب', 'Teil B', 'Part B'))}</span><h2>${E(T('کار عملی', 'Praxis', 'Practice'))}</h2><ul>
<li>${E(T(`${num(N_TICKETS)} تیکت تصادفی در شبیه‌ساز سیستم تیکت: پرسیدن، دسته‌بندی، اولویت، یادداشت، حل یا ارجاع`, `${N_TICKETS} zufällige Tickets im Ticketsystem-Simulator: nachfragen, einordnen, priorisieren, dokumentieren, lösen oder weiterleiten`, `${N_TICKETS} random tickets in the ticket system simulator: ask, classify, prioritise, document, solve or escalate`))}</li>
<li>${E(T('هر تیکت ۱۰۰ امتیاز دارد؛ فقط تلاش‌هایی که بعد از شروع آزمون انجام شوند حساب می‌شوند', 'Jedes Ticket bringt bis zu 100 Punkte; es zählen nur Versuche nach dem Prüfungsstart', 'Each ticket is worth up to 100 points; only attempts made after the exam starts count'))}</li>
<li>${E(T(`قبولی: میانگین دست‌کم ${num(PASS_B)} امتیاز`, `Bestanden ab durchschnittlich ${PASS_B} Punkten`, `Pass mark: an average of ${PASS_B} points`))}</li></ul></div>
</section>
<section class="ex-start card"><label class="note-label" for="ex-name">${E(T('نام تو برای گواهی (اختیاری)', 'Dein Name für den Lernnachweis (freiwillig)', 'Your name for the certificate (optional)'))}</label>
<div class="ex-row"><input id="ex-name" class="wsc-input" maxlength="80" autocomplete="name" value="${E(st.name || '')}"><button type="button" class="btn" data-ex="start">${E(T('شروع آزمون', 'Prüfung starten', 'Start the exam'))}</button></div>
<label class="ex-extra"><input type="checkbox" id="ex-extra"> <span>${E(T(`زمان بیشتر: ${num(Math.round(MINUTES * 1.5))} دقیقه به‌جای ${num(MINUTES)} (مثلاً برای خواندن به زبان دوم یا نیاز به زمان بیشتر)`, `Mehr Zeit: ${Math.round(MINUTES * 1.5)} statt ${MINUTES} Minuten (etwa wenn du in einer Zweitsprache liest oder mehr Zeit brauchst)`, `More time: ${Math.round(MINUTES * 1.5)} instead of ${MINUTES} minutes (for example if you read in a second language or need more time)`))}</span></label>
<p class="micro">${E(T('نکته: پیش از آزمون، آزمونک ماژول‌ها و شبیه‌ساز تیکت را تمرین کن. نتیجه فقط در همین مرورگر ذخیره می‌شود.', 'Tipp: Übe vorher die Wissenschecks der Module und den Ticket-Simulator. Das Ergebnis wird nur in diesem Browser gespeichert.', 'Tip: practise the module quizzes and the ticket simulator first. The result is stored only in this browser.'))}</p></section>
${last ? resultCard(last) : ''}
${hist.length > (last ? 1 : 0) ? `<section class="ex-hist"><h2>${E(T('تلاش‌های قبلی', 'Bisherige Versuche', 'Previous attempts'))}</h2><table><thead><tr><th>${E(T('تاریخ', 'Datum', 'Date'))}</th><th>${E(T('دانش', 'Wissen', 'Knowledge'))}</th><th>${E(T('عملی', 'Praxis', 'Practice'))}</th><th>${E(T('نتیجه', 'Ergebnis', 'Result'))}</th></tr></thead><tbody>${hist.map(h => `<tr><td>${E(new Date(h.date).toLocaleDateString(loc))}</td><td>${pc(h.a)}</td><td>${num(h.b)}</td><td>${h.pass ? '✓ ' + E(T('قبول', 'bestanden', 'passed')) : E(T('هنوز نه', 'noch nicht', 'not yet'))}</td></tr>`).join('')}</tbody></table></section>` : ''}
<p class="ex-legal micro">${E(T('این آزمون بخشی از برنامهٔ یادگیری Arefi ITPraxis است و گواهی آن «گواهی یادگیری» است؛ آزمون دولتی، LAP یا گواهی رسمی سازنده‌ها (مثل Microsoft، Cisco یا CompTIA) نیست.', 'Diese Prüfung ist Teil des Lernprogramms Arefi ITPraxis; der Nachweis ist ein Lernnachweis – keine staatliche Prüfung, keine LAP und kein offizielles Herstellerzertifikat (etwa Microsoft, Cisco oder CompTIA).', 'This exam is part of the Arefi ITPraxis learning program; its certificate is a certificate of learning – not a state exam, apprenticeship exam or official vendor certification (such as Microsoft, Cisco or CompTIA).'))}</p>`;
}
function partAView(cur) {
 const ps = paths(), answered = Object.keys(cur.a).length;
 let k = -1;
 const groups = ps.map(p => {
  const items = cur.qs.map((x, i) => [x, i]).filter(([x]) => x.p === p.no);
  if (!items.length) return '';
  return `<section class="ex-group"><h2><span>${num(p.no)}</span>${E(P(p.t))}</h2>${items.map(([x, i]) => { const q = qById(x.id); if (!q) return ''; k++; return `<fieldset class="ex-q"><legend><span class="ex-qn">${num(k + 1)}</span>${E(P(q.q))}</legend>${x.o.map((oi, j) => `<label class="quiz-option"><input type="radio" name="exq${i}" data-exq="${i}" value="${j}"${cur.a[i] === j ? ' checked' : ''}> <span>${E(P(q.opts[oi]))}</span></label>`).join('')}</fieldset>`; }).join('')}</section>`;
 }).join('');
 return `<div class="ex-bar"><b tabindex="-1">${E(T('بخش الف: دانش', 'Teil A: Wissen', 'Part A: Knowledge'))}</b><span id="ex-count">${num(answered)} / ${num(cur.qs.length)} ${E(T('پاسخ داده شد', 'beantwortet', 'answered'))}</span><span class="ex-timer" id="ex-timer" aria-live="off">${mmss(left(cur))}</span><span class="visually-hidden" id="ex-live" aria-live="polite"></span><button type="button" class="btn" data-ex="submitA">${E(T('ثبت پاسخ‌ها', 'Antworten abgeben', 'Submit answers'))}</button><button type="button" class="btn secondary ex-abort" data-ex="abort">${E(T('لغو آزمون', 'Prüfung abbrechen', 'Cancel exam'))}</button></div>
<p class="micro">${E(T('هر پرسش یک پاسخ درست دارد. می‌توانی برگردی و پاسخ را عوض کنی؛ پاسخ‌ها خودکار ذخیره می‌شوند.', 'Jede Frage hat genau eine richtige Antwort. Du kannst zurückgehen und Antworten ändern; alles wird automatisch gespeichert.', 'Each question has exactly one correct answer. You can go back and change answers; everything is saved automatically.'))}</p>
${groups}
<div class="ex-end"><button type="button" class="btn" data-ex="submitA">${E(T('ثبت پاسخ‌ها و رفتن به بخش ب', 'Antworten abgeben und weiter zu Teil B', 'Submit answers and continue to part B'))}</button></div>`;
}
function partBView(cur) {
 const a = cur.resA, b = scoreB(cur);
 return `<div class="ex-bar"><b tabindex="-1">${E(T('بخش ب: کار عملی', 'Teil B: Praxis', 'Part B: Practice'))}</b><span>${E(T('نتیجهٔ بخش الف', 'Ergebnis Teil A', 'Part A result'))}: ${pc(a.pct)} ${a.pct >= PASS_A ? '✓' : ''}</span></div>
<section class="card ex-b"><h2>${E(T('این سه تیکت را در شبیه‌ساز حل کن', 'Bearbeite diese drei Tickets im Simulator', 'Work through these three tickets in the simulator'))}</h2>
<p>${E(T('هر تیکت را باز کن، مثل کار واقعی کامل انجامش بده و ببند. اگر قبلاً همین تیکت را حل کرده‌ای، در صفحهٔ تیکت «دوباره از اول» را بزن. بعد به همین صفحه برگرد.', 'Öffne jedes Ticket, bearbeite es vollständig wie im echten Job und schließe es ab. Hast du das Ticket schon früher gelöst, klicke dort auf „Noch einmal von vorn“. Komm danach auf diese Seite zurück.', 'Open each ticket, work through it fully like on the job and close it. If you solved that ticket before, click “Start again” on the ticket page. Then come back to this page.'))}</p>
<ol class="ex-tk">${b.rows.map(r => `<li><a href="#ticketdesk/${E(r.id)}">${E(tTitle(r.id))}</a><span class="${r.done ? 'is-ok' : ''}">${r.done ? num(r.pts) + ' ' + E(T('امتیاز', 'Punkte', 'points')) : E(T('باز', 'offen', 'open'))}</span></li>`).join('')}</ol>
<p class="micro">${num(b.done)} / ${num(b.rows.length)} ${E(T('تیکت انجام شد', 'Tickets erledigt', 'tickets done'))} · ${E(T('میانگین فعلی', 'aktueller Durchschnitt', 'current average'))}: ${num(b.pct)}</p>
<div class="ex-row"><button type="button" class="btn secondary ex-abort" data-ex="abort">${E(T('لغو آزمون', 'Prüfung abbrechen', 'Cancel exam'))}</button><button type="button" class="btn" data-ex="finish">${E(T('پایان آزمون و دیدن نتیجه', 'Prüfung beenden und Ergebnis ansehen', 'Finish the exam and see the result'))}</button></div>
${b.done < b.rows.length ? `<p class="micro">${E(T('تیکت باز با صفر امتیاز حساب می‌شود.', 'Offene Tickets zählen mit 0 Punkten.', 'Open tickets count as 0 points.'))}</p>` : ''}</section>`;
}
function resultCard(res) {
 const ps = paths();
 return `<section class="card ex-res ${res.pass ? 'is-pass' : 'is-fail'}"><h2>${E(res.pass ? T('قبول شدی', 'Bestanden', 'Passed') : T('هنوز قبول نشدی', 'Noch nicht bestanden', 'Not passed yet'))}</h2>
<dl class="ex-sum"><div><dt>${E(T('بخش الف: دانش', 'Teil A: Wissen', 'Part A: Knowledge'))}</dt><dd>${pc(res.a)} <small>(${num(res.aok)}/${num(res.an)})</small></dd></div><div><dt>${E(T('بخش ب: عملی', 'Teil B: Praxis', 'Part B: Practice'))}</dt><dd>${num(res.b)} <small>/ ${num(100)}</small></dd></div></dl>
<table class="ex-per"><thead><tr><th>${E(T('مسیر یادگیری', 'Lernpfad', 'Learning path'))}</th><th>${E(T('درست', 'richtig', 'correct'))}</th></tr></thead><tbody>${res.per.map(x => { const p = ps.find(y => y.no === x.no); return `<tr${x.ok / x.n < 0.6 ? ' class="is-weak"' : ''}><td>${num(x.no)} ${E(p ? P(p.t) : '')}</td><td>${num(x.ok)}/${num(x.n)}</td></tr>`; }).join('')}</tbody></table>
${res.per.some(x => x.ok / x.n < 0.6) ? `<p class="micro">${E(T('مسیرهای علامت‌دار را دوباره مرور کن: بخش عیب‌یابی و آزمونک ماژول‌ها.', 'Wiederhole die markierten Lernpfade: Fehlersuche und Wissenschecks der Module.', 'Revise the highlighted learning paths: troubleshooting and module quizzes.'))}</p>` : ''}
<div class="ex-row">${res.pass ? `<button type="button" class="btn" data-ex="cert">${E(T('گواهی یادگیری با لوگو', 'Lernnachweis mit Logo', 'Certificate of learning with logo'))}</button>` : ''}<button type="button" class="btn secondary" data-ex="again">${E(T('آزمون دوباره', 'Prüfung wiederholen', 'Take the exam again'))}</button></div></section>`;
}
function page() {
 const st = load(), cur = st.cur;
 let body, note = '';
 if (cur && cur.stage === 'a' && paths().length && !valid(cur)) { delete st.cur; save(st); note = `<p class="card ex-note" role="status">${E(T('محتوای دوره‌ها به‌روز شده است؛ آزمون نیمه‌کاره با محتوای جدید جور نیست. لطفاً آزمون را دوباره شروع کن.', 'Die Kursinhalte wurden aktualisiert; der angefangene Versuch passt nicht mehr dazu. Bitte starte die Prüfung neu.', 'The course content was updated; the unfinished attempt no longer matches it. Please start the exam again.'))}</p>`; return `<div class="ex" id="ex-root">${note}${introView(st)}</div>`; }
 if (cur && cur.stage === 'a') body = partAView(cur);
 else if (cur && cur.stage === 'b') body = partBView(cur);
 else body = introView(st);
 return `<div class="ex" id="ex-root">${body}</div>`;
}
function draw(focus) { const root = document.querySelector('#ex-root'); if (root) { root.outerHTML = page(); mount(); if (focus) { const h = document.querySelector('#ex-root .ex-bar b, #ex-root h1, #ex-root .ex-res h2'); if (h) { if (!h.hasAttribute('tabindex')) h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); } } } }
function tick() {
 const st = load(), cur = st.cur, el = document.querySelector('#ex-timer');
 if (!cur || cur.stage !== 'a' || !el) { clearInterval(timer); timer = null; return; }
 const s = left(cur); el.textContent = mmss(s); el.classList.toggle('is-low', s <= 300);
 const lv = document.querySelector('#ex-live'), m = s / 60; if (lv && (m === 10 || m === 5 || m === 1)) lv.textContent = T(`${num(m)} دقیقه باقی مانده است`, `Noch ${m} ${m === 1 ? 'Minute' : 'Minuten'}`, `${m} ${m === 1 ? 'minute' : 'minutes'} left`);
 if (s <= 0) { submitA(); draw(); }
}
function mount() {
 clearInterval(timer); timer = null;
 const st = load();
 if (st.cur && st.cur.stage === 'a') { if (left(st.cur) <= 0) { submitA(); draw(); return; } timer = setInterval(tick, 1000); }
}

/* ---------- Lernnachweis ---------- */
function cert(res) {
 const d = new Date(res.date), loc = { fa: 'fa-IR', de: 'de-DE', en: 'en-GB' }[lang()];
 const date = d.toLocaleDateString(loc, { year: 'numeric', month: 'long', day: 'numeric' });
 let h = 2166136261; for (const ch of (res.name + res.date + res.a + res.b)) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); }
 const ref = 'ITP-EXAM-' + d.toISOString().slice(0, 10).replace(/-/g, '') + '-' + ((h >>> 0) % 1048576).toString(16).toUpperCase().padStart(5, '0');
 const mark = window.ArefiBrand && window.ArefiBrand.mark ? window.ArefiBrand.mark('axc-mark') : '';
 const prev = document.activeElement; const old = document.querySelector('#ax-cert'); if (old) old.remove();
 const el = document.createElement('div'); el.id = 'ax-cert'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-label', T('گواهی یادگیری', 'Lernnachweis', 'Certificate of learning'));
 el.setAttribute('dir', lang() === 'fa' ? 'rtl' : 'ltr'); el.setAttribute('lang', lang());
 el.innerHTML = `<div class="axc-tools"><button type="button" class="btn" data-c="print">${E(T('چاپ یا ذخیره به‌صورت PDF', 'Drucken oder als PDF speichern', 'Print or save as PDF'))}</button><button type="button" class="btn secondary" data-c="close">${E(T('بستن', 'Schließen', 'Close'))}</button></div>
<article class="axc-page"><div class="axc-frame">
<header class="axc-head" dir="ltr">${mark}<div><b>Arefi <span>ITPraxis</span></b><small>Lernen wie im echten IT-Job</small></div></header>
<h1>${E(T('گواهی یادگیری', 'Lernnachweis', 'Certificate of learning'))}</h1>
<p class="axc-intro">${E(T('بدین‌وسیله تأیید می‌شود که', 'Hiermit wird bestätigt, dass', 'This is to confirm that'))}</p><p class="axc-name">${E(res.name || T('شرکت‌کننده', 'Teilnehmer/in', 'Participant'))}</p>
<p class="axc-intro">${E(T('آزمون پایانی زیر را با موفقیت گذرانده است:', 'die folgende Abschlussprüfung bestanden hat:', 'has passed the following final exam:'))}</p>
<p class="axc-course">${E(T('آزمون پایانی Arefi ITPraxis – پشتیبانی و فناوری اطلاعات در عمل', 'Abschlussprüfung Arefi ITPraxis – IT-Support und Systemtechnik in der Praxis', 'Arefi ITPraxis final exam – IT support and systems in practice'))}</p>
<dl class="axc-facts"><div><dt>${E(T(`دانش (${num(res.per.length)} مسیر)`, `Wissen (${res.per.length} Lernpfade)`, `Knowledge (${res.per.length} paths)`))}</dt><dd>${pc(res.a)}</dd></div><div><dt>${E(T('عملی (تیکت)', 'Praxis (Tickets)', 'Practice (tickets)'))}</dt><dd>${num(res.b)} / ${num(100)}</dd></div><div><dt>${E(T('تاریخ', 'Datum', 'Date'))}</dt><dd>${E(date)}</dd></div><div><dt>${E(T('شماره', 'Nachweis-Nr.', 'Reference'))}</dt><dd dir="ltr">${E(ref)}</dd></div></dl>
<p class="axc-note">${E(T('گواهی یادگیری برنامهٔ Arefi ITPraxis. آزمون در خود برنامه انجام شده و نتیجه فقط روی دستگاه شرکت‌کننده ذخیره شده است. این گواهی آزمون دولتی، LAP یا گواهی رسمی سازنده‌ها نیست.', 'Lernnachweis des Lernprogramms Arefi ITPraxis. Die Prüfung wurde im Programm abgelegt, das Ergebnis ist nur auf dem Gerät der Person gespeichert. Keine staatliche Prüfung, keine LAP und kein offizielles Herstellerzertifikat.', 'Certificate of learning from the Arefi ITPraxis learning program. The exam was taken in the program and the result is stored only on the participant’s device. Not a state exam, apprenticeship exam or official vendor certification.'))}</p></div></article>`;
 document.body.appendChild(el); document.body.classList.add('cert-open');
 const onKey = e => {
  if (e.key === 'Escape') { e.preventDefault(); close(); return; }
  if (e.key === 'Tab') { const f = [...el.querySelectorAll('button')]; if (!f.length) return; const i = f.indexOf(document.activeElement); if (e.shiftKey && i <= 0) { e.preventDefault(); f[f.length - 1].focus(); } else if (!e.shiftKey && i === f.length - 1) { e.preventDefault(); f[0].focus(); } else if (i < 0) { e.preventDefault(); f[0].focus(); } }
 };
 const close = () => { el.remove(); document.body.classList.remove('cert-open'); removeEventListener('keydown', onKey); removeEventListener('hashchange', close); if (prev && prev.isConnected && prev.focus) prev.focus(); };
 addEventListener('keydown', onKey); addEventListener('hashchange', close);
 el.addEventListener('click', e => { const b = e.target.closest('[data-c]'); if (!b) return; if (b.dataset.c === 'print') window.print(); else close(); });
 el.querySelector('[data-c="print"]').focus();
}

/* ---------- Ereignisse ---------- */
document.addEventListener('click', e => {
 const b = e.target.closest && e.target.closest('#ex-root [data-ex]'); if (!b) return;
 e.preventDefault();
 const k = b.dataset.ex;
 if (k === 'start') { if (!paths().length) return; const n = document.querySelector('#ex-name'), x = document.querySelector('#ex-extra'); start(n ? n.value.trim() : '', !!(x && x.checked)); draw(true); window.scrollTo && window.scrollTo({ top: 0 }); }
 else if (k === 'submitA') {
  const st = load(); if (!st.cur) return;
  const open = st.cur.qs.length - Object.keys(st.cur.a).length;
  if (open > 0 && !window.confirm(T(`${num(open)} پرسش بی‌پاسخ است. با این حال ثبت شود؟`, `${open} Fragen sind noch offen. Trotzdem abgeben?`, `${open} questions are unanswered. Submit anyway?`))) return;
  submitA(); draw(true); window.scrollTo && window.scrollTo({ top: 0 });
 }
 else if (k === 'finish') { finish(); draw(true); window.scrollTo && window.scrollTo({ top: 0 }); }
 else if (k === 'abort') { if (!window.confirm(T('آزمون لغو شود؟ پاسخ‌های این تلاش حذف می‌شوند.', 'Prüfung abbrechen? Die Antworten dieses Versuchs werden verworfen.', 'Cancel the exam? The answers of this attempt will be discarded.'))) return; const st = load(); delete st.cur; save(st); draw(true); }
 else if (k === 'again') { const st = load(); delete st.last; save(st); draw(); }
 else if (k === 'cert') { const st = load(); if (st.last && st.last.pass) cert(st.last); }
});
document.addEventListener('change', e => {
 const el = e.target; if (!el.matches || !el.matches('#ex-root [data-exq]')) return;
 const st = load(); if (!st.cur || st.cur.stage !== 'a') return;
 if (left(st.cur) <= 0) { submitA(); draw(true); return; }
 st.cur.a[+el.dataset.exq] = +el.value; save(st);
 const c = document.querySelector('#ex-count'); if (c) c.textContent = `${num(Object.keys(st.cur.a).length)} / ${num(st.cur.qs.length)} ${T('پاسخ داده شد', 'beantwortet', 'answered')}`;
});

/* Anzeige auf anderen Seiten, solange eine Prüfung läuft (Zeit in Teil A, Rückweg in Teil B) */
let pillTimer = null;
function pill() {
 let el = document.querySelector('#ex-pill');
 const st = load(), cur = st.cur, onExam = /^#pruefung/.test(location.hash);
 if (!cur || onExam) { if (el) el.remove(); document.body.classList.remove('has-ex-pill'); clearInterval(pillTimer); pillTimer = null; return; }
 if (cur.stage === 'a' && left(cur) <= 0) { submitA(); }
 const cur2 = load().cur; if (!cur2) return;
 if (!el) { el = document.createElement('a'); el.id = 'ex-pill'; el.href = '#pruefung'; document.body.appendChild(el); document.body.classList.add('has-ex-pill'); }
 el.textContent = cur2.stage === 'a' ? `${T('آزمون پایانی در جریان است', 'Abschlussprüfung läuft', 'Final exam in progress')} · ${mmss(left(cur2))} · ${T('بازگشت', 'zurück', 'back')}` : `${T('آزمون پایانی: بخش ب – بازگشت به آزمون', 'Abschlussprüfung Teil B – zurück zur Prüfung', 'Final exam part B – back to the exam')}`;
 if (!pillTimer) pillTimer = setInterval(pill, 1000);
}
window.addEventListener('hashchange', () => setTimeout(pill, 50));
document.addEventListener('DOMContentLoaded', () => setTimeout(pill, 300));
setTimeout(pill, 500);

const title = () => T('آزمون پایانی', 'Abschlussprüfung', 'Final exam');
window.ArefiExt = Object.assign(window.ArefiExt || {}, { pruefung: { page, mount, title } });
window.ArefiExam = { start, scoreA, scoreB, submitA, finish, load, paths };
})();
