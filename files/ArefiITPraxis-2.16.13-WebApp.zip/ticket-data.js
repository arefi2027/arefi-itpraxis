/* Ticket-Desk: Simulation eines Ticketsystems. Jedes Ticket baut auf einem Alltagsfall (workCases) auf.
   ans[] gehört Index für Index zu case.<sprache>.ask[]. impact/urgency: 1 hoch … 3 niedrig. expect: 'solve' oder Gruppe für Weiterleitung. */
window.LAB = window.LAB || {};
window.LAB.ticketDesk = {
 groups: {
  l1: { de: '1st Level Service Desk (du)', en: '1st level service desk (you)', fa: 'میز خدمات سطح ۱ (خودت)' },
  client: { de: '2nd Level Arbeitsplatz', en: '2nd level workplace', fa: 'سطح ۲ محیط کار' },
  net: { de: 'Netzwerk-Team', en: 'Network team', fa: 'تیم شبکه' },
  m365: { de: 'Microsoft 365 / Exchange', en: 'Microsoft 365 / Exchange', fa: 'Microsoft 365 / Exchange' },
  sec: { de: 'IT-Sicherheit', en: 'IT security', fa: 'امنیت IT' },
  server: { de: 'Server und Anwendungen', en: 'Servers and applications', fa: 'سرور و نرم‌افزارها' }
 },
 channels: { phone: { de: 'Telefon', en: 'Phone', fa: 'تلفن' }, mail: { de: 'E-Mail', en: 'Email', fa: 'ایمیل' }, portal: { de: 'Self-Service-Portal', en: 'Self-service portal', fa: 'پرتال سلف‌سرویس' } },
 /* allgemeine Rückfragen, die in jedem Ticket zur Auswahl stehen */
 extra: [
  { kind: 'neutral', q: { de: 'Haben Sie den PC schon neu gestartet?', en: 'Have you restarted the PC already?', fa: 'رایانه را ری‌استارت کرده‌اید؟' },
    a: { de: 'Ja, heute Morgen schon. Hat nichts geändert.', en: 'Yes, this morning. It didn\'t change anything.', fa: 'بله، امروز صبح. فرقی نکرد.' } },
  { kind: 'useless', q: { de: 'Welche Grafikkarte ist in Ihrem PC eingebaut?', en: 'Which graphics card is in your PC?', fa: 'کارت گرافیک رایانهٔ شما چیست؟' },
    a: { de: 'Das weiß ich wirklich nicht. Ist das wichtig?', en: 'I really don\'t know. Is that important?', fa: 'واقعاً نمی‌دانم. مهم است؟' } },
  { kind: 'bad', q: { de: 'Sagen Sie mir bitte Ihr Kennwort, dann prüfe ich das.', en: 'Please tell me your password and I\'ll check it.', fa: 'لطفاً گذرواژه‌تان را بگویید تا بررسی کنم.' },
    a: { de: 'Ähm … in der Schulung hieß es, man gibt das Kennwort nie weiter, auch nicht an die IT.', en: 'Erm … the training said never to share your password, not even with IT.', fa: 'اِم… در آموزش گفتند گذرواژه را هیچ‌وقت به کسی نده، حتی به IT.' } }
 ],
 tickets: [
  { id: 'password', no: 'INC0024101', type: 'inc', ch: 'phone', impact: 3, urgency: 1, expect: 'solve', wrong: ['trust', 'ca-block'],
    who: { n: 'Lena Weber', d: { de: 'Einkauf', en: 'Purchasing', fa: 'خرید' } },
    ans: {
     de: ['Lena Weber, Einkauf. Meine Durchwahl ist 1234.', 'Da steht: „Das Konto ist gesperrt und kann nicht verwendet werden.“', 'Ja, gestern musste ich es ändern. Auf dem Handy habe ich die Firmen-Mails, dort habe ich nichts umgestellt.'],
     en: ['Lena Weber, purchasing. My extension is 1234.', 'It says: "The referenced account is currently locked out."', 'Yes, I had to change it yesterday. My work email is on my phone and I didn\'t change anything there.'],
     fa: ['لنا وبر از بخش خرید. شمارهٔ داخلی من ۱۲۳۴ است.', 'نوشته: «حساب کاربری قفل شده و قابل استفاده نیست.»', 'بله، دیروز مجبور شدم عوضش کنم. ایمیل کاری روی گوشی‌ام هست و آنجا چیزی را عوض نکردم.'] } },
  { id: 'mfa', no: 'INC0024102', type: 'inc', ch: 'phone', impact: 3, urgency: 1, expect: 'solve', wrong: ['mobile', 'license'],
    who: { n: 'Tobias Klein', d: { de: 'Vertrieb', en: 'Sales', fa: 'فروش' } },
    ans: {
     de: ['Das alte Handy habe ich im Zug verloren.', 'Nein, eingerichtet war nur die App.', 'Ein Videoanruf am Handy geht, meinen Dienstausweis habe ich dabei.'],
     en: ['I lost the old phone on the train.', 'No, only the app was set up.', 'A video call on my phone works, and I have my staff ID with me.'],
     fa: ['گوشی قدیمی را در قطار گم کردم.', 'نه، فقط همان اپ تنظیم شده بود.', 'تماس تصویری با گوشی ممکن است و کارت کارمندی‌ام همراهم است.'] } },
  { id: 'onboarding', no: 'REQ0008831', type: 'req', ch: 'portal', impact: 3, urgency: 2, expect: 'solve', wrong: ['offboarding', 'password'],
    who: { n: 'Sandra Berg', d: { de: 'Personalabteilung', en: 'HR', fa: 'منابع انسانی' } },
    ans: {
     de: ['Ja, Auftrag #4711 ist freigegeben: Sabine Neumann, Vertrieb, Start am Montag, Kostenstelle 4300, Vorgesetzter Herr Fuchs.', 'Vertriebsinnendienst wie Herr Fuchs: Gruppe Vertrieb, CRM, Office-Lizenz Business Premium.', 'Ein Notebook mit Dockingstation im 2. Stock und ein Firmenhandy. VPN braucht sie erst in drei Monaten.'],
     en: ['Yes, order #4711 is approved: Sabine Neumann, sales, starting Monday, cost centre 4300, manager Mr Fuchs.', 'Sales back office like Mr Fuchs: sales group, CRM, Office licence Business Premium.', 'A notebook with docking station on the 2nd floor and a company phone. She only needs VPN in three months.'],
     fa: ['بله، سفارش ‎#4711 تأیید شده: سابینه نویمان، فروش، شروع دوشنبه، مرکز هزینه ۴۳۰۰، سرپرست آقای فوکس.', 'پشتیبانی داخلی فروش مثل آقای فوکس: گروه فروش، CRM، لایسنس Office Business Premium.', 'یک لپ‌تاپ با داک در طبقهٔ دوم و یک گوشی شرکتی. VPN را تازه سه ماه بعد لازم دارد.'] } },
  { id: 'outlook', no: 'INC0024107', type: 'inc', ch: 'phone', impact: 3, urgency: 1, expect: 'solve', wrong: ['teams-login', 'license'],
    who: { n: 'Jana Hofer', d: { de: 'Buchhaltung', en: 'Accounting', fa: 'حسابداری' } },
    ans: {
     de: ['Im Browser unter outlook.office.com geht es, Teams auch.', 'Mein Kollege hat kein Problem.', 'Gestern wurde ein neues PDF-Programm installiert, das hat auch etwas in Outlook eingebaut.'],
     en: ['It works in the browser at outlook.office.com, and Teams works too.', 'My colleague has no problem.', 'Yesterday a new PDF program was installed, and it added something to Outlook.'],
     fa: ['در مرورگر با outlook.office.com کار می‌کند و Teams هم کار می‌کند.', 'همکارم مشکلی ندارد.', 'دیروز یک برنامهٔ PDF تازه نصب شد که چیزی هم به Outlook اضافه کرد.'] } },
  { id: 'sharedmailbox', no: 'REQ0008840', type: 'req', ch: 'mail', impact: 3, urgency: 2, expect: 'solve', wrong: ['ndr', 'mailboxfull'],
    who: { n: 'Lena Weber', d: { de: 'Einkauf', en: 'Purchasing', fa: 'خرید' } },
    ans: {
     de: ['Frau Berg ist zuständig. Sie hat es mir gestern per Mail bestätigt, ich leite Ihnen die Mail weiter.', 'Ich muss die Mails bearbeiten und auch als info@ antworten.', 'Dauerhaft, ab heute.'],
     en: ['Ms Berg is responsible. She confirmed it by email yesterday, I\'ll forward you that email.', 'I need to work on the emails and also reply as info@.', 'Permanently, from today.'],
     fa: ['خانم برگ مسئول است. دیروز با ایمیل تأیید کرد؛ ایمیلش را برایتان می‌فرستم.', 'باید ایمیل‌ها را رسیدگی کنم و با نام info@ هم جواب بدهم.', 'دائمی، از امروز.'] } },
  { id: 'teams-av', no: 'INC0024113', type: 'inc', ch: 'phone', impact: 3, urgency: 1, expect: 'solve', wrong: ['teams-login', 'onedrive'],
    who: { n: 'Ali Rezaei', d: { de: 'Vertrieb', en: 'Sales', fa: 'فروش' } },
    ans: {
     de: ['Ein USB-Headset und die eingebaute Kamera vom Notebook.', 'Bis gestern ging alles. Heute früh war ein Windows-Update.', 'Nein, nur Teams und Outlook sind offen.'],
     en: ['A USB headset and the notebook\'s built-in camera.', 'Everything worked until yesterday. There was a Windows update this morning.', 'No, only Teams and Outlook are open.'],
     fa: ['یک هدست USB و دوربین داخلی لپ‌تاپ.', 'تا دیروز همه‌چیز کار می‌کرد. امروز صبح یک آپدیت ویندوز نصب شد.', 'نه، فقط Teams و Outlook باز است.'] } },
  { id: 'nonet', no: 'INC0024118', type: 'inc', ch: 'phone', impact: 2, urgency: 1, expect: 'solve', wrong: ['wlan', 'rogue-dhcp'],
    who: { n: 'Petra Huber', d: { de: 'Empfang', en: 'Reception', fa: 'پذیرش' } },
    ans: {
     de: ['Mein Kollege nebenan kann normal arbeiten.', 'Mit Kabel über die Dockingstation. Am Anschluss vom Dock leuchtet nichts.', 'Heute früh wurde unter dem Tisch geputzt.'],
     en: ['My colleague next to me can work normally.', 'Cable through the docking station. Nothing lights up at the dock\'s port.', 'The floor under the desk was cleaned this morning.'],
     fa: ['همکار کناری‌ام عادی کار می‌کند.', 'با کابل از طریق داک. روی پورت داک هیچ چراغی روشن نیست.', 'امروز صبح زیر میز را تمیز کردند.'] } },
  { id: 'netdrive', no: 'INC0024120', type: 'inc', ch: 'portal', impact: 3, urgency: 1, expect: 'solve', wrong: ['vpn-subnet', 'dns'],
    who: { n: 'Mehmet Arslan', d: { de: 'Controlling', en: 'Controlling', fa: 'کنترلینگ' } },
    ans: {
     de: ['F: ist noch da, aber beim Öffnen kommt „Zugriff verweigert“.', 'Ich bin im Büro.', 'Ja, bis letzten Monat. Seit 1. Juni bin ich vom Finanzteam ins Controlling gewechselt.'],
     en: ['F: is still there, but opening it says "Access denied".', 'I\'m in the office.', 'Yes, until last month. On 1 June I moved from the finance team to controlling.'],
     fa: ['درایو F: هست، ولی موقع باز کردن «Access denied» می‌آید.', 'در دفتر هستم.', 'بله، تا ماه پیش. از اول ژوئن از تیم مالی به کنترلینگ منتقل شدم.'] } },
  { id: 'vpn', no: 'INC0024125', type: 'inc', ch: 'phone', impact: 3, urgency: 1, expect: 'solve', wrong: ['vpn-subnet', 'nonet'],
    who: { n: 'Stefan Gruber', d: { de: 'Außendienst', en: 'Field sales', fa: 'فروش میدانی' } },
    ans: {
     de: ['Ja, Nachrichtenseiten und YouTube gehen normal.', 'Fehler 691: Benutzername oder Kennwort ungültig. Ich schicke Ihnen einen Screenshot.', 'Ich bin zu Hause. Gestern ging es noch, heute früh kam ein Hinweis, dass mein Kennwort abläuft.'],
     en: ['Yes, news sites and YouTube work normally.', 'Error 691: user name or password invalid. I\'ll send you a screenshot.', 'I\'m at home. It worked yesterday; this morning a notice said my password is expiring.'],
     fa: ['بله، سایت‌های خبری و YouTube عادی کار می‌کنند.', 'خطای 691: نام کاربری یا گذرواژه نامعتبر است. اسکرین‌شات می‌فرستم.', 'خانه هستم. دیروز کار می‌کرد؛ امروز صبح پیامی آمد که گذرواژه‌ام منقضی می‌شود.'] } },
  { id: 'slowpc', no: 'INC0024131', type: 'inc', ch: 'portal', impact: 3, urgency: 2, expect: 'solve', wrong: ['boot', 'winupdate'],
    who: { n: 'Karin Leitner', d: { de: 'Buchhaltung', en: 'Accounting', fa: 'حسابداری' } },
    ans: {
     de: ['Seit ein paar Wochen, es wird immer schlimmer.', 'Eigentlich bei allem, Excel ist am schlimmsten.', 'Ich klappe das Notebook nur zu. Richtig aus war es seit über einem Monat nicht.'],
     en: ['For a few weeks, and it keeps getting worse.', 'With everything really, Excel is the worst.', 'I just close the lid. It hasn\'t been properly shut down for over a month.'],
     fa: ['چند هفته است و هر روز بدتر می‌شود.', 'تقریباً در همه‌چیز، Excel از همه بدتر است.', 'فقط درِ لپ‌تاپ را می‌بندم. بیش از یک ماه است که درست خاموش نشده.'] } },
  { id: 'printer', no: 'INC0024136', type: 'inc', ch: 'phone', impact: 3, urgency: 1, expect: 'solve', wrong: ['scan', 'usb'],
    who: { n: 'Bettina Sommer', d: { de: 'Planung', en: 'Planning', fa: 'برنامه‌ریزی' } },
    ans: {
     de: ['Der Farbdrucker im 2. Stock, „OG2-Farbdrucker“.', 'Ja, meine Kollegin hat gerade gedruckt, bei ihr geht es.', 'Nein, das Display zeigt „Bereit“. Ich hatte vorhin einen großen Bauplan als PDF geschickt.'],
     en: ['The colour printer on the 2nd floor, "OG2 colour printer".', 'Yes, my colleague just printed and it works for her.', 'No, the display says "Ready". Earlier I sent a large building plan as a PDF.'],
     fa: ['چاپگر رنگی طبقهٔ دوم، «OG2-Farbdrucker».', 'بله، همکارم همین الان چاپ کرد و برای او کار می‌کند.', 'نه، صفحه «Ready» نشان می‌دهد. کمی پیش یک نقشهٔ ساختمانی بزرگ را به‌صورت PDF فرستادم.'] } },
  { id: 'phishing', no: 'INC0024140', type: 'inc', ch: 'phone', impact: 1, urgency: 1, expect: 'sec', wrong: ['cert', 'mailboxfull'],
    who: { n: 'Lena Weber', d: { de: 'Einkauf', en: 'Purchasing', fa: 'خرید' } },
    ans: {
     de: ['Ich habe auf den Link geklickt und mein Kennwort eingegeben. Danach kam am Handy eine Anmeldeanfrage, die habe ich bestätigt.', 'Gerade eben, so um 9:10 Uhr.', 'Absender war „Microsoft Support“ mit einer Adresse auf .info. Die Mail habe ich noch.'],
     en: ['I clicked the link and entered my password. Then a sign-in request came up on my phone and I approved it.', 'Just now, around 9:10.', 'The sender was "Microsoft Support" with an address ending in .info. I still have the email.'],
     fa: ['روی لینک کلیک کردم و گذرواژه‌ام را وارد کردم. بعد یک درخواست ورود روی گوشی آمد که تأییدش کردم.', 'همین الان، حدود ساعت ۹:۱۰.', 'فرستنده «Microsoft Support» با آدرسی که به ‎.info ختم می‌شد. ایمیل هنوز هست.'] } },
  { id: 'major', no: 'INC0024150', type: 'inc', ch: 'phone', impact: 1, urgency: 1, expect: 'server', wrong: ['rds', 'dns'],
    who: { n: { de: '14 Anrufe in 10 Minuten', en: '14 calls in 10 minutes', fa: '۱۴ تماس در ۱۰ دقیقه' }, d: { de: 'mehrere Abteilungen', en: 'several departments', fa: 'چند بخش' } },
    ans: {
     de: ['Alle drei Standorte, Verkauf und Lager.', 'Seit etwa 8:05 Uhr. Die Meldung: „Verbindung zum Server konnte nicht hergestellt werden – Zertifikat ungültig“.', 'E-Mail, Internet und Teams gehen ganz normal.'],
     en: ['All three sites, sales and warehouse.', 'Since about 8:05. The message: "Could not connect to the server – certificate invalid".', 'Email, internet and Teams work normally.'],
     fa: ['هر سه شعبه، فروش و انبار.', 'از حدود ساعت ۸:۰۵. پیام: «اتصال به سرور برقرار نشد – گواهی نامعتبر است».', 'ایمیل، اینترنت و Teams عادی کار می‌کنند.'] } },
  { id: 'mailboxfull', no: 'INC0024158', type: 'inc', ch: 'phone', impact: 3, urgency: 1, expect: 'solve', wrong: ['ndr', 'license'],
    who: { n: 'Lena Weber', d: { de: 'Einkauf', en: 'Purchasing', fa: 'خرید' } },
    ans: {
     de: ['Seit gestern Nachmittag. Interne Mails kommen auch nicht mehr an.', '„Ihr Postfach ist voll. Sie können keine Nachrichten mehr senden oder empfangen.“', 'Ich hebe alles auf. Bei „Gesendete Elemente“ sind Jahre an Angeboten mit großen Anhängen.', 'Ein Archiv? Davon weiß ich nichts.'],
     en: ['Since yesterday afternoon. Internal emails don\'t arrive either.', '"Your mailbox is full. You can no longer send or receive messages."', 'I keep everything. "Sent Items" has years of quotes with large attachments.', 'An archive? I don\'t know anything about that.'],
     fa: ['از دیروز بعدازظهر. ایمیل‌های داخلی هم نمی‌رسند.', '«صندوق پستی شما پر است. دیگر نمی‌توانید پیام بفرستید یا دریافت کنید.»', 'همه‌چیز را نگه می‌دارم. در «Sent Items» سال‌ها پیشنهاد قیمت با پیوست‌های بزرگ هست.', 'بایگانی؟ چیزی درباره‌اش نمی‌دانم.'] } },
  { id: 'dns', no: 'INC0024163', type: 'inc', ch: 'phone', impact: 3, urgency: 1, expect: 'solve', wrong: ['rogue-dhcp', 'vpn-subnet'],
    who: { n: 'Daniel Novak', d: { de: 'Vertrieb', en: 'Sales', fa: 'فروش' } },
    ans: {
     de: ['Seit heute früh, nur bei mir. Die Kollegen arbeiten normal.', 'intranet.firma.local, Meldung: „Diese Website ist nicht erreichbar – Server-IP-Adresse nicht gefunden“.', 'Im Büro, mit Kabel.', 'Ja, letzte Woche war ich auf einer Messe im Hotel. Das WLAN ging schlecht und ein Bekannter hat mir etwas umgestellt.'],
     en: ['Since this morning, only me. My colleagues work normally.', 'intranet.firma.local, message: "This site can\'t be reached – server IP address could not be found".', 'In the office, on cable.', 'Yes, last week I was at a trade fair in a hotel. The Wi-Fi was bad and a friend changed something for me.'],
     fa: ['از امروز صبح، فقط برای من. همکاران عادی کار می‌کنند.', 'intranet.firma.local، پیام: «این سایت در دسترس نیست – آدرس IP سرور پیدا نشد».', 'در دفتر، با کابل.', 'بله، هفتهٔ پیش برای نمایشگاه در هتل بودم. وای‌فای بد بود و یک آشنا چیزی را برایم تغییر داد.'] } }
 ]
};
/* Wissensseite „So funktionieren Ticketsysteme“. Produktangaben nur als grobe Einordnung, ohne Marktanteile. */
window.LAB.ticketDesk.info = {
 de: [
  ['Was ist ein Ticketsystem?', '<p>Jede Meldung an die IT bekommt eine eigene Nummer, zum Beispiel <bdi>INC0024101</bdi>. Im Ticket steht, wer was gemeldet hat, wer daran arbeitet, was schon versucht wurde und wann es gelöst wurde. So geht nichts verloren, Kolleginnen können übernehmen, und die Firma sieht, wie viele Anfragen es gibt und wie schnell sie erledigt werden.</p><p>Tickets kommen per Telefon, E-Mail, Self-Service-Portal, Chat oder automatisch aus der Überwachung (Monitoring).</p>'],
  ['Der Weg eines Tickets', '<ol class="td-steps"><li><b>Neu:</b> Meldung kommt herein. Erfassen: Melder, Rückrufnummer, Beschreibung mit genauer Fehlermeldung.</li><li><b>Einordnen:</b> Typ, Kategorie, Auswirkung und Dringlichkeit festlegen. Daraus ergibt sich die Priorität.</li><li><b>Zuweisen:</b> Der 1st Level bearbeitet selbst oder gibt an eine Gruppe weiter (2nd Level, Netzwerk, Sicherheit …).</li><li><b>In Arbeit:</b> Rückfragen, Prüfen, Lösen. Jeder Schritt kommt in die interne Notiz.</li><li><b>Warten auf Benutzer:</b> Die Uhr für die Lösungszeit wird in vielen Firmen angehalten, solange du auf eine Antwort wartest.</li><li><b>Gelöst:</b> Lösung an den Benutzer, er kann noch widersprechen.</li><li><b>Geschlossen:</b> nach Bestätigung oder automatisch nach einigen Tagen. Häufige Lösungen werden zu Wissensartikeln.</li></ol>'],
  ['Die wichtigsten Begriffe (ITIL)', '<dl class="td-dl"><dt>Incident (Störung)</dt><dd>Etwas, das funktionieren sollte, geht nicht oder schlechter. Ziel: so schnell wie möglich wieder arbeiten.</dd><dt>Service Request (Anfrage)</dt><dd>Nichts ist kaputt, jemand möchte etwas: neues Konto, Zugriff, Gerät, Software.</dd><dt>Major Incident</dt><dd>Großstörung mit vielen Betroffenen. Ein Haupt-Ticket, die Einzelmeldungen werden damit verknüpft, Teamleitung wird sofort informiert.</dd><dt>Problem</dt><dd>Die gemeinsame Ursache hinter wiederholten Störungen. Wird getrennt untersucht, damit es nicht wieder passiert.</dd><dt>Change</dt><dd>Eine geplante Änderung an Systemen, mit Freigabe, Termin und Rückfallplan.</dd></dl>'],
  ['Priorität: Auswirkung × Dringlichkeit', '<p><b>Auswirkung</b> fragt: Wie viele sind betroffen und wie wichtig ist es für die Firma? <b>Dringlichkeit</b> fragt: Wie schnell wird es schlimm, gibt es einen Workaround? In dieser Übungsfirma gilt:</p>@MATRIX@<p>Das Beispiel-SLA der Übungsfirma (echte Zeiten stehen im SLA deiner Firma):</p>@SLA@'],
  ['Gut dokumentieren', '<ul><li><b>Interne Notiz</b> (sieht nur die IT): Fakten, Uhrzeiten, genaue Fehlermeldung, was geprüft und geändert wurde, Ergebnis.</li><li><b>Antwort an den Benutzer</b> (öffentlich): freundlich, ohne Fachchinesisch, mit dem, was er jetzt tun soll.</li><li>Schreibe so, dass eine Kollegin morgen ohne Rückfrage weitermachen kann.</li><li>Niemals Kennwörter ins Ticket, und frage nie nach dem Kennwort eines Benutzers.</li><li>Bei Weiterleitung: Übergabenotiz mit allem, was du schon weißt und getan hast. Der 2nd Level soll nicht noch einmal dieselben Fragen stellen.</li></ul>'],
  ['Welche Ticketsysteme Firmen nutzen', '<p>Die Abläufe sind überall gleich, nur Oberfläche und Begriffe unterscheiden sich. Häufig genannt in Stellenanzeigen:</p>@TOOLS@<p>Kleine Firmen arbeiten manchmal noch mit einem geteilten Postfach oder einer Excel-Liste. Ein Ticketsystem löst genau deren Probleme: keine Nummer, keine Zuständigkeit, keine Auswertung.</p>'],
  ['Üben und im Vorstellungsgespräch nennen', '<ul><li>Installiere <b>Zammad</b> oder <b>GLPI</b> in einer Linux-VM deines Labs (z. B. LNX01), lege Benutzer und Gruppen an und spiele die Tickets aus diesem Simulator dort nach.</li><li>Im Gespräch: „Ich kenne den Ablauf Incident und Service Request, priorisiere nach Auswirkung und Dringlichkeit, dokumentiere intern und öffentlich getrennt und leite mit vollständiger Übergabe weiter. Geübt habe ich mit Zammad in meinem Lab.“</li><li>Diese Simulation zeigt die Prinzipien. Sie ist kein Nachbau eines bestimmten Produkts.</li></ul>']
 ],
 en: [
  ['What is a ticket system?', '<p>Every report to IT gets its own number, for example <bdi>INC0024101</bdi>. The ticket records who reported what, who is working on it, what has been tried and when it was solved. Nothing gets lost, colleagues can take over, and the company can see how many requests come in and how fast they are handled.</p><p>Tickets come in by phone, email, self-service portal, chat or automatically from monitoring.</p>'],
  ['The life of a ticket', '<ol class="td-steps"><li><b>New:</b> the report comes in. Record reporter, call-back number and a description with the exact error message.</li><li><b>Classify:</b> set type, category, impact and urgency. These give the priority.</li><li><b>Assign:</b> the 1st level works on it or passes it to a group (2nd level, network, security …).</li><li><b>In progress:</b> ask questions, check, fix. Every step goes into the internal note.</li><li><b>Waiting for user:</b> many companies pause the resolution clock while you wait for an answer.</li><li><b>Resolved:</b> the solution goes to the user, who can still object.</li><li><b>Closed:</b> after confirmation or automatically after a few days. Common solutions become knowledge articles.</li></ol>'],
  ['Key terms (ITIL)', '<dl class="td-dl"><dt>Incident</dt><dd>Something that should work doesn\'t, or works worse. Goal: get people working again as fast as possible.</dd><dt>Service request</dt><dd>Nothing is broken, someone wants something: new account, access, device, software.</dd><dt>Major incident</dt><dd>A large outage with many affected users. One main ticket, the individual reports are linked to it, and the team lead is informed at once.</dd><dt>Problem</dt><dd>The common cause behind repeated incidents. Investigated separately so it doesn\'t happen again.</dd><dt>Change</dt><dd>A planned change to systems, with approval, date and rollback plan.</dd></dl>'],
  ['Priority: impact × urgency', '<p><b>Impact</b> asks: how many are affected and how important is it for the company? <b>Urgency</b> asks: how fast does it get bad, is there a workaround? In this practice company:</p>@MATRIX@<p>The practice company\'s example SLA (real times are in your company\'s SLA):</p>@SLA@'],
  ['Documenting well', '<ul><li><b>Internal note</b> (IT only): facts, times, exact error message, what was checked and changed, result.</li><li><b>Reply to the user</b> (public): friendly, no jargon, with what they should do now.</li><li>Write so a colleague can continue tomorrow without asking you.</li><li>Never put passwords in a ticket, and never ask a user for their password.</li><li>When forwarding: a handover note with everything you already know and did. The 2nd level should not have to ask the same questions again.</li></ul>'],
  ['Which ticket systems companies use', '<p>The process is the same everywhere; only the interface and wording differ. Often named in job ads:</p>@TOOLS@<p>Small companies sometimes still work with a shared mailbox or an Excel list. A ticket system solves exactly their problems: no number, no owner, no reporting.</p>'],
  ['Practise it and mention it in interviews', '<ul><li>Install <b>Zammad</b> or <b>GLPI</b> in a Linux VM in your lab (e.g. LNX01), create users and groups and replay the tickets from this simulator there.</li><li>In the interview: "I know the incident and service request process, prioritise by impact and urgency, keep internal and public notes separate and forward with a complete handover. I practised with Zammad in my lab."</li><li>This simulation shows the principles. It is not a copy of any particular product.</li></ul>']
 ],
 fa: [
  ['سیستم تیکت چیست؟', '<p>هر گزارشی که به IT می‌رسد یک شمارهٔ جدا می‌گیرد، مثلاً <bdi>INC0024101</bdi>. در تیکت ثبت می‌شود چه کسی چه چیزی گزارش کرده، چه کسی رویش کار می‌کند، چه کارهایی امتحان شده و کی حل شده است. این‌طوری چیزی گم نمی‌شود، همکار می‌تواند کار را ادامه دهد و شرکت می‌بیند چند درخواست می‌آید و با چه سرعتی حل می‌شود.</p><p>تیکت‌ها از تلفن، ایمیل، پرتال سلف‌سرویس، چت یا خودکار از سیستم پایش (Monitoring) می‌آیند.</p>'],
  ['مسیر یک تیکت', '<ol class="td-steps"><li><b>جدید (Neu):</b> گزارش می‌رسد. ثبت کن: گزارش‌دهنده، شمارهٔ تماس، شرح با متن دقیق خطا.</li><li><b>دسته‌بندی:</b> نوع، دسته، اثر (Auswirkung) و فوریت (Dringlichkeit) را تعیین کن. اولویت از همین‌ها درمی‌آید.</li><li><b>واگذاری:</b> سطح ۱ خودش کار می‌کند یا به یک گروه می‌سپارد (سطح ۲، شبکه، امنیت …).</li><li><b>در حال انجام (In Arbeit):</b> پرسیدن، بررسی، حل. هر قدم در یادداشت داخلی ثبت می‌شود.</li><li><b>در انتظار کاربر (Warten auf Benutzer):</b> در خیلی از شرکت‌ها ساعت زمان حل تا رسیدن جواب متوقف می‌شود.</li><li><b>حل‌شده (Gelöst):</b> راه‌حل برای کاربر فرستاده می‌شود و او هنوز می‌تواند اعتراض کند.</li><li><b>بسته‌شده (Geschlossen):</b> بعد از تأیید یا خودکار بعد از چند روز. راه‌حل‌های پرتکرار مقالهٔ دانش (Wissensartikel) می‌شوند.</li></ol>'],
  ['مهم‌ترین اصطلاحات (ITIL)', '<dl class="td-dl"><dt>Incident (اختلال)</dt><dd>چیزی که باید کار کند کار نمی‌کند یا بد کار می‌کند. هدف: کاربر هرچه زودتر دوباره کار کند.</dd><dt>Service Request (درخواست)</dt><dd>چیزی خراب نیست، کسی چیزی می‌خواهد: حساب جدید، دسترسی، دستگاه، نرم‌افزار.</dd><dt>Major Incident (اختلال بزرگ)</dt><dd>قطعی بزرگ با کاربران زیاد. یک تیکت اصلی ساخته می‌شود، گزارش‌های جداگانه به آن وصل می‌شوند و سرپرست تیم فوراً خبر می‌شود.</dd><dt>Problem</dt><dd>علت مشترک پشت اختلال‌های تکراری. جدا بررسی می‌شود تا دوباره رخ ندهد.</dd><dt>Change</dt><dd>تغییر برنامه‌ریزی‌شده در سیستم‌ها، با تأیید، زمان‌بندی و برنامهٔ بازگشت.</dd></dl>'],
  ['اولویت: اثر × فوریت', '<p><b>اثر (Auswirkung)</b> می‌پرسد: چند نفر درگیرند و برای شرکت چقدر مهم است؟ <b>فوریت (Dringlichkeit)</b> می‌پرسد: چقدر زود اوضاع بد می‌شود، راه موقت هست؟ در این شرکت تمرینی:</p>@MATRIX@<p>SLA نمونهٔ شرکت تمرینی (زمان‌های واقعی در SLA شرکت خودت است):</p>@SLA@'],
  ['مستندسازی درست', '<ul><li><b>یادداشت داخلی</b> (فقط IT می‌بیند): واقعیت‌ها، ساعت‌ها، متن دقیق خطا، چه چیزی بررسی و تغییر داده شد، نتیجه.</li><li><b>پاسخ به کاربر</b> (عمومی): مؤدبانه، بدون اصطلاحات فنی، با کاری که الان باید بکند.</li><li>طوری بنویس که همکارت فردا بدون پرسیدن از تو ادامه دهد.</li><li>هرگز گذرواژه را در تیکت ننویس و هرگز گذرواژهٔ کاربر را نپرس.</li><li>هنگام ارجاع: یادداشت تحویل با همهٔ چیزهایی که می‌دانی و انجام داده‌ای. سطح ۲ نباید همان سؤال‌ها را دوباره بپرسد.</li></ul>'],
  ['شرکت‌ها از کدام سیستم‌های تیکت استفاده می‌کنند', '<p>روند کار همه‌جا یکی است؛ فقط ظاهر و واژه‌ها فرق دارد. در آگهی‌های شغلی زیاد دیده می‌شوند:</p>@TOOLS@<p>شرکت‌های کوچک گاهی هنوز با یک صندوق ایمیل مشترک یا فهرست Excel کار می‌کنند. سیستم تیکت دقیقاً مشکل همین‌ها را حل می‌کند: نه شماره هست، نه مسئول، نه گزارش.</p>'],
  ['تمرین کن و در مصاحبه بگو', '<ul><li><b>Zammad</b> یا <b>GLPI</b> را روی یک VM لینوکسی در آزمایشگاهت (مثلاً LNX01) نصب کن، کاربر و گروه بساز و تیکت‌های همین شبیه‌ساز را آنجا دوباره اجرا کن.</li><li>در مصاحبه به آلمانی بگو: <span lang="de" dir="ltr">„Ich kenne den Ablauf Incident und Service Request, priorisiere nach Auswirkung und Dringlichkeit, dokumentiere intern und öffentlich getrennt und leite mit vollständiger Übergabe weiter. Geübt habe ich mit Zammad in meinem Lab.“</span></li><li>این شبیه‌ساز اصول را نشان می‌دهد و نسخهٔ بدلی هیچ محصول خاصی نیست.</li></ul>']
 ],
 tools: [
  ['ServiceNow', { de: 'kommerziell, Cloud', en: 'commercial, cloud', fa: 'تجاری، ابری' }, { de: 'Konzerne und große IT-Abteilungen', en: 'large enterprises and big IT departments', fa: 'شرکت‌های بزرگ و دپارتمان‌های IT بزرگ' }],
  ['Jira Service Management', { de: 'kommerziell (Atlassian), Cloud oder eigener Server', en: 'commercial (Atlassian), cloud or self-hosted', fa: 'تجاری (Atlassian)، ابری یا روی سرور خود شرکت' }, { de: 'IT- und Entwicklungsteams, die schon Jira nutzen', en: 'IT and development teams already using Jira', fa: 'تیم‌های IT و توسعه که از Jira استفاده می‌کنند' }],
  ['TOPdesk', { de: 'kommerziell, aus den Niederlanden', en: 'commercial, from the Netherlands', fa: 'تجاری، از هلند' }, { de: 'Mittelstand, Behörden, Schulen; IT, Haustechnik und Personal in einem System', en: 'mid-sized companies, public sector, schools; IT, facilities and HR in one system', fa: 'شرکت‌های متوسط، ادارات، مدارس؛ IT، تأسیسات و منابع انسانی در یک سیستم' }],
  ['Matrix42', { de: 'kommerziell, aus Deutschland', en: 'commercial, from Germany', fa: 'تجاری، از آلمان' }, { de: 'Service-Management zusammen mit Geräte- und Softwareverwaltung', en: 'service management together with device and software management', fa: 'مدیریت سرویس همراه با مدیریت دستگاه و نرم‌افزار' }],
  ['ManageEngine ServiceDesk Plus', { de: 'kommerziell', en: 'commercial', fa: 'تجاری' }, { de: 'kleine und mittlere IT-Abteilungen', en: 'small and mid-sized IT departments', fa: 'دپارتمان‌های IT کوچک و متوسط' }],
  ['Freshservice', { de: 'kommerziell, Cloud', en: 'commercial, cloud', fa: 'تجاری، ابری' }, { de: 'kleine und mittlere Firmen', en: 'small and mid-sized companies', fa: 'شرکت‌های کوچک و متوسط' }],
  ['Zendesk', { de: 'kommerziell, Cloud', en: 'commercial, cloud', fa: 'تجاری، ابری' }, { de: 'eher Kundenservice als interne IT', en: 'more customer service than internal IT', fa: 'بیشتر خدمات مشتری تا IT داخلی' }],
  ['ConnectWise, Datto Autotask, HaloPSA', { de: 'kommerziell, mit Zeiterfassung und Abrechnung', en: 'commercial, with time tracking and billing', fa: 'تجاری، با ثبت زمان و صورت‌حساب' }, { de: 'IT-Dienstleister (MSP), die Tickets für viele Kundenfirmen bearbeiten', en: 'IT service providers (MSPs) handling tickets for many client companies', fa: 'شرکت‌های خدمات IT (MSP) که برای چندین شرکت مشتری تیکت رسیدگی می‌کنند' }],
  ['Zammad', { de: 'Open Source, aus Deutschland, auch als Cloud', en: 'open source, from Germany, also as cloud', fa: 'متن‌باز، از آلمان، نسخهٔ ابری هم دارد' }, { de: 'KMU, Schulen, Vereine; gut für das eigene Lab', en: 'SMEs, schools, associations; good for your own lab', fa: 'شرکت‌های کوچک، مدارس، انجمن‌ها؛ مناسب برای آزمایشگاه خودت' }],
  ['Znuny, OTOBO', { de: 'Open Source, Weiterführungen der früheren OTRS Community Edition', en: 'open source, continuations of the former OTRS Community Edition', fa: 'متن‌باز، ادامهٔ نسخهٔ رایگان قبلی OTRS' }, { de: 'Firmen, die ihr System selbst betreiben', en: 'companies running their own system', fa: 'شرکت‌هایی که سیستم را خودشان اجرا می‌کنند' }],
  ['GLPI', { de: 'Open Source', en: 'open source', fa: 'متن‌باز' }, { de: 'Inventar und Helpdesk in einem', en: 'inventory and helpdesk in one', fa: 'فهرست دارایی‌ها و هلپ‌دسک در یکجا' }],
  ['osTicket', { de: 'Open Source', en: 'open source', fa: 'متن‌باز' }, { de: 'einfacher Einstieg für kleine Teams', en: 'simple start for small teams', fa: 'شروع ساده برای تیم‌های کوچک' }]
 ]
};
