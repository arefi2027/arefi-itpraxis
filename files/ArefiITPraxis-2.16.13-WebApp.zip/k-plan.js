/* Arefi ITPraxis – Lernstrecke Netzwerkplanung und Projektmanagement: Registrierung. Projektmappen in k-plan-p-*.js. */
(() => {
'use strict';
const C = window.ArefiKPlan = window.ArefiKPlan || { modules: [] };
window.ArefiCourseRegister({
  id: 'plan', group: 2, shell: 'PowerShell', C,
  title: ['برنامه‌ریزی شبکه: از خانه تا شرکت بزرگ', 'Netzwerke planen: von Privat bis zur großen Firma', 'Planning networks: from home to large company'],
  lead: [
    'در این فصل یاد می‌گیری شبکهٔ یک خانه یا شرکت را همان‌طور برنامه‌ریزی کنی که در کار واقعی از تکنسین می‌خواهند: از پرسیدن نیاز تا تحویل پروژه. ۱۳ درس روش را قدم‌به‌قدم یاد می‌دهند و ۴ پروژهٔ نمونه نشان می‌دهند نتیجهٔ کار در عمل چه شکلی دارد.',
    'In diesem Kapitel lernst du, das Netz einer Wohnung oder Firma so zu planen, wie es im IT-Job verlangt wird – vom Bedarf bis zur Übergabe. 13 Lektionen lehren die Methode Schritt für Schritt, 4 Musterprojekte zeigen, wie das Ergebnis in der Praxis aussieht.',
    'In this chapter you learn to plan the network of a home or company the way IT jobs expect it – from gathering needs to handing over. 13 lessons teach the method step by step, and 4 model projects show what the result looks like in practice.'
  ],
  howto: {
    title: ['این فصل را این‌طور پیش ببر', 'So arbeitest du mit diesem Kapitel', 'How to work through this chapter'],
    steps: [
      [['درس‌ها را به ترتیب بخوان', 'Lektionen der Reihe nach durcharbeiten', 'Work through the lessons in order'],
       ['درس ۱ تا ۹ روش فنی را یاد می‌دهند (نیاز و نقشه، نوع شبکه، VLAN و IP، دسترسی از بیرون، امنیت، دسترس‌پذیری، کیفیت، کابل‌کشی، هزینه) و درس ۱۰ تا ۱۳ مدیریت پروژه و قانون را. هر درس تمرین، عیب‌یابی و آزمونک دارد.', 'Lektion 1–9 lehren die Technik (Bedarf und Netzplan, Netztyp, VLAN und IP, Erreichbarkeit, Sicherheit, Verfügbarkeit, Qualität, Verkabelung, Kosten), Lektion 10–13 Projektmanagement und Recht. Jede Lektion hat Übung, Fehlersuche und Wissenscheck.', 'Lessons 1–9 teach the technical method (needs and diagram, network type, VLAN and IP, reachability, security, availability, quality, cabling, cost), lessons 10–13 project management and law. Every lesson has an exercise, troubleshooting and a quiz.']],
      [['یک پروژهٔ نمونه را ببین', 'Ein Musterprojekt ansehen', 'Look at a model project'],
       ['بعد از درس‌ها، پایین همین صفحه یک پوشهٔ پروژه را باز کن؛ اول «خانه» که ساده‌ترین است. آنجا همان بخش‌های درس‌ها را در یک پروژهٔ کامل می‌بینی.', 'Öffne danach unten auf dieser Seite eine Projektmappe, zuerst „Privat“ – sie ist am einfachsten. Dort siehst du die Bereiche aus den Lektionen als fertiges Projekt.', 'After the lessons, open a project folder further down this page – start with “Home”, the simplest. There you see the areas from the lessons as a finished project.']],
      [['خودت انجام بده', 'Selbst machen', 'Do it yourself'],
       ['در پوشه «قالب خالی برای تمرین» را بزن، سند را برای یک شرکت دیگر پر کن و با «نمونهٔ کامل» مقایسه کن. پوشهٔ «مقایسه» در آخر نشان می‌دهد با بزرگ‌تر شدن شرکت چه چیزی عوض می‌شود.', 'Wähle in der Mappe „Vorlage zum Ausfüllen“, fülle das Dokument für eine andere Firma aus und vergleiche es mit der „Musterlösung“. Die Mappe „Vergleich“ zeigt zum Schluss, was sich mit der Firmengröße ändert.', 'In the folder choose “Blank template”, fill in the document for another company and compare it with the “Model solution”. The “Comparison” folder at the end shows what changes as a company grows.']]
    ]
  },
  projectOrder: ['p-privat', 'p-klein', 'p-mittel', 'p-gross', 'p-vergleich'],
  startProject: 'p-privat',
  part: [['بخش ۱: روش‌های فنی برنامه‌ریزی شبکه', 'Teil 1: Technische Planungsmethoden', 'Part 1: Technical planning methods'], ['بخش ۲: روش‌های مدیریت پروژه و حقوق', 'Teil 2: Projektmanagement und Recht', 'Part 2: Project management and law']],
  projects: window.ArefiPlanProjects || []
});
})();
