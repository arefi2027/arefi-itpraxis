/* Ticket-Desk: simuliertes Ticketsystem. Warteschlange, Ticket mit Rückfragen und simulierten Antworten,
   Einordnung (Typ, Kategorie, Auswirkung × Dringlichkeit), interne Notiz, Lösen oder Weiterleiten, Bewertung.
   Daten: ticket-data.js und die Alltagsfälle (work-cases*.js). Ergebnisse: state.work.desk (Export, Import, Sicherung).
   Adresse: #ticketdesk, #ticketdesk/info, #ticketdesk/<ticket-id> */
(() => {
'use strict';
const D = window.LAB, TD = D && D.ticketDesk;
if (!TD) return;
const J = D.workJobs || { areas: {}, prio: {} };
const W = () => window.ArefiWork;
const lang = () => { const l = document.documentElement.lang; return l === 'de' || l === 'en' ? l : 'fa'; };
const T = (fa, de, en) => ({ fa, de, en })[lang()];
const L = o => (o && typeof o === 'object' ? (o[lang()] || o.de) : o) || '';
const E = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = n => lang() === 'fa' ? String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]) : String(n);
const caseOf = t => (D.workCases || []).find(c => c.id === t.id);
const tById = id => TD.tickets.find(t => t.id === id);
const MIN_TXT = 30;

/* ---------- feste Begriffe ---------- */
const TYPES = { inc: { de: 'Incident (Störung)', en: 'Incident', fa: 'Incident (اختلال)' }, req: { de: 'Service Request (Anfrage)', en: 'Service request', fa: 'Service Request (درخواست)' } };
const IMP = {
 1: { de: '1 · hoch: viele Benutzer, ein Standort oder die ganze Firma', en: '1 · high: many users, a site or the whole company', fa: '۱ · زیاد: کاربران زیاد، یک شعبه یا کل شرکت' },
 2: { de: '2 · mittel: Team, Abteilung oder ein kritischer Arbeitsplatz', en: '2 · medium: a team, a department or a critical workstation', fa: '۲ · متوسط: یک تیم، یک بخش یا یک میز کار حیاتی' },
 3: { de: '3 · niedrig: eine Person', en: '3 · low: one person', fa: '۳ · کم: یک نفر' } };
const URG = {
 1: { de: '1 · hoch: Arbeit steht, kein Workaround', en: '1 · high: work has stopped, no workaround', fa: '۱ · زیاد: کار متوقف است، راه موقت نیست' },
 2: { de: '2 · mittel: eingeschränkt, Workaround oder Termin in den nächsten Tagen', en: '2 · medium: limited, workaround or a deadline in the next days', fa: '۲ · متوسط: محدود، راه موقت یا موعد در چند روز آینده' },
 3: { de: '3 · niedrig: kann warten', en: '3 · low: can wait', fa: '۳ · کم: می‌تواند صبر کند' } };
const SLA = { 1: ['15 Min', '4 Std'], 2: ['30 Min', '8 Std'], 3: ['4 Std', '2 AT'], 4: ['1 AT', '5 AT'] };
const slaTxt = v => lang() === 'de' ? v : lang() === 'en' ? v.replace('Min', 'min').replace('Std', 'h').replace('AT', 'working days').replace(/^1 working days$/, '1 working day') : num(v.replace('Min', 'دقیقه').replace('Std', 'ساعت').replace('AT', 'روز کاری'));
const STATUS = {
 new: { de: 'Neu', en: 'New', fa: 'جدید' }, work: { de: 'In Arbeit', en: 'In progress', fa: 'در حال انجام' },
 wait: { de: 'Warten auf Benutzer', en: 'Waiting for user', fa: 'در انتظار کاربر' },
 solved: { de: 'Gelöst', en: 'Resolved', fa: 'حل‌شده' }, fwd: { de: 'Weitergeleitet', en: 'Forwarded', fa: 'ارجاع‌شده' } };
const prioOf = (i, u) => Math.min(4, i + u - 1);
const groupsFwd = ['client', 'net', 'm365', 'sec', 'server'];

/* ---------- Zustand ---------- */
const S = { run: {}, msg: '' };
function seed(s) { let h = 2166136261; for (const ch of s) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0; return () => (h = Math.imul(h ^ (h >>> 15), 2246822507) >>> 0) / 4294967296; }
function shuffle(list, key) { const r = seed(key), a = list.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
function startMin(t) { return 8 * 60 + 2 + TD.tickets.indexOf(t) * 7; }
function run(t) {
 if (!S.run[t.id]) S.run[t.id] = { asked: [], sel: [], thread: [{ k: 'msg', m: startMin(t) }], f: { type: '', area: '', imp: '', urg: '' }, note: '', mode: '', fix: '', group: '', text: '', status: 'new', clock: startMin(t) + 3, res: null, busy: false };
 return S.run[t.id];
}
function store() { const w = W() && W().ws(); if (!w) return {}; if (!w.desk || typeof w.desk !== 'object') w.desk = {}; return w.desk; }
const hhmm = m => num(String(Math.floor(m / 60) % 24).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'));

/* ---------- Texte zu Rückfragen und Antworten ---------- */
function qIds(t) { const c = caseOf(t); return shuffle(c.de.ask.map((_, i) => 'a' + i).concat(TD.extra.map((_, i) => 'x' + i)), t.id); }
function qText(t, id, l = lang()) { const c = caseOf(t); return id[0] === 'a' ? (c[l] || c.de).ask[+id.slice(1)] : TD.extra[+id.slice(1)].q[l]; }
function aText(t, id, l = lang()) { return id[0] === 'a' ? (t.ans[l] || t.ans.de)[+id.slice(1)] : TD.extra[+id.slice(1)].a[l]; }
const whoName = t => L(t.who.n);
const deLine = txt => lang() === 'de' ? '' : `<p class="td-de" lang="de" dir="ltr">${E(txt)}</p>`;
function fixOpts(t) { return shuffle([t.id].concat(t.wrong), t.id + '/fix'); }
const fixText = id => { const c = (D.workCases || []).find(x => x.id === id); return c ? L(c).fix : ''; };

/* ---------- Bewertung ---------- */
function grade(t, r) {
 const c = caseOf(t), it = [];
 const add = (got, max, label, why) => it.push({ got, max, label, why });
 const exp = prioOf(t.impact, t.urgency), mine = prioOf(+r.f.imp, +r.f.urg), d = Math.abs(exp - mine);
 add(r.f.type === t.type ? 5 : 0, 5, T('نوع تیکت', 'Ticket-Typ', 'Ticket type'), r.f.type === t.type ? T('درست.', 'Richtig.', 'Correct.') : T('درست: ', 'Richtig wäre: ', 'Expected: ') + L(TYPES[t.type]) + (t.type === 'req' ? T(' — چیزی خراب نیست، چیزی درخواست شده.', ' – nichts ist kaputt, es wird etwas angefordert.', ' – nothing is broken, something is being requested.') : T(' — چیزی که باید کار کند کار نمی‌کند.', ' – etwas, das gehen sollte, geht nicht.', ' – something that should work does not.')));
 add(r.f.area === c.area ? 10 : 0, 10, T('دسته', 'Kategorie', 'Category'), r.f.area === c.area ? T('درست.', 'Richtig.', 'Correct.') : T('درست: ', 'Richtig wäre: ', 'Expected: ') + L(J.areas[c.area]));
 add(d === 0 ? 15 : d === 1 ? 7 : 0, 15, T('اولویت', 'Priorität', 'Priority'), (d === 0 ? T('درست: ', 'Richtig: ', 'Correct: ') : T('تو: ', 'Deine Wahl: ', 'Your choice: ') + 'P' + num(mine) + ' · ' + T('درست: ', 'richtig: ', 'expected: ')) + 'P' + num(exp) + ' (' + T('اثر ', 'Auswirkung ', 'impact ') + num(t.impact) + ' × ' + T('فوریت ', 'Dringlichkeit ', 'urgency ') + num(t.urgency) + ').');
 const n = c.de.ask.length, k = r.asked.filter(x => x[0] === 'a').length;
 let qp = Math.round(25 * k / n), notes = [T(`${num(k)} از ${num(n)} پرسش مهم پرسیده شد.`, `${k} von ${n} wichtigen Rückfragen gestellt.`, `${k} of ${n} important questions asked.`)];
 TD.extra.forEach((x, i) => { if (!r.asked.includes('x' + i)) return; if (x.kind === 'useless') { qp -= 3; notes.push(T('پرسش بی‌ربط (کارت گرافیک): ۳−', 'Unnötige Frage (Grafikkarte): −3', 'Irrelevant question (graphics card): −3')); } if (x.kind === 'bad') { qp -= 15; notes.push(T('گذرواژه پرسیدی: IT هرگز گذرواژهٔ کاربر را نمی‌پرسد. ۱۵−', 'Nach dem Kennwort gefragt: Das fragt die IT nie. −15', 'Asked for the password: IT never asks for it. −15')); } });
 add(Math.max(0, qp), 25, T('پرسش‌ها', 'Rückfragen', 'Questions'), notes.join(' '));
 const noteOk = r.note.trim().length >= MIN_TXT;
 add(noteOk ? 10 : 0, 10, T('یادداشت داخلی', 'Interne Notiz', 'Internal note'), noteOk ? T('ثبت شد.', 'Vorhanden.', 'Present.') : T(`ندارد یا کوتاه است (حداقل ${num(MIN_TXT)} نویسه).`, `Fehlt oder zu kurz (mindestens ${MIN_TXT} Zeichen).`, `Missing or too short (at least ${MIN_TXT} characters).`));
 let cp = 0, cw;
 if (t.expect === 'solve') {
  if (r.mode === 'solve' && r.fix === t.id) { cp = 25; cw = T('علت و راه‌حل درست.', 'Richtige Ursache und Lösung.', 'Correct cause and solution.'); }
  else if (r.mode === 'solve') cw = T('این راه‌حل به این تیکت نمی‌خورد. پاسخ‌های کاربر را دوباره بخوان.', 'Diese Lösung passt nicht zu dem Ticket. Lies die Antworten des Benutzers noch einmal.', 'That solution does not fit this ticket. Read the user\'s answers again.');
  else { cp = 8; cw = T('ارجاع لازم نبود؛ سطح ۱ این را خودش حل می‌کند.', 'Weiterleiten war nicht nötig, das löst der 1st Level selbst.', 'Forwarding was not needed; the 1st level solves this itself.'); }
 } else {
  const g = L(TD.groups[t.expect]);
  if (r.mode === 'fwd' && r.group === t.expect) { cp = 25; cw = T('ارجاع درست به ', 'Richtig weitergeleitet an ', 'Correctly forwarded to ') + g + '.'; }
  else if (r.mode === 'fwd') { cp = 12; cw = T('ارجاع درست بود، ولی گروه درست: ', 'Weiterleiten war richtig, aber an: ', 'Forwarding was right, but to: ') + g + '.'; }
  else if (r.fix === t.id) { cp = 12; cw = T('اقدام‌های اولیه درست‌اند، ولی این تیکت باید به ', 'Die Erstmaßnahmen stimmen, aber das Ticket gehört an ', 'The first steps are right, but this ticket belongs to ') + g + T(' برود و سطح ۱ آن را نمی‌بندد.', ' und wird nicht vom 1st Level geschlossen.', ' and is not closed by the 1st level.'); }
  else cw = T('این تیکت باید ارجاع شود به ', 'Dieses Ticket muss weitergeleitet werden an ', 'This ticket must be forwarded to ') + g + '.';
 }
 add(cp, 25, T('بستن یا ارجاع', 'Lösen oder Weiterleiten', 'Resolve or forward'), cw);
 const txOk = r.text.trim().length >= MIN_TXT;
 add(txOk ? 10 : 0, 10, r.mode === 'fwd' ? T('یادداشت تحویل', 'Übergabenotiz', 'Handover note') : T('پاسخ به کاربر', 'Antwort an den Benutzer', 'Reply to the user'), txOk ? T('ثبت شد.', 'Vorhanden.', 'Present.') : T(`ندارد یا کوتاه است (حداقل ${num(MIN_TXT)} نویسه).`, `Fehlt oder zu kurz (mindestens ${MIN_TXT} Zeichen).`, `Missing or too short (at least ${MIN_TXT} characters).`));
 return { items: it, total: it.reduce((s, x) => s + x.got, 0) };
}

/* ---------- Ansichten ---------- */
function head(sub) {
 const tabs = [['', T('صف تیکت‌ها', 'Warteschlange', 'Queue')], ['info', T('سیستم تیکت چطور کار می‌کند', 'So funktionieren Ticketsysteme', 'How ticket systems work')]];
 return `<div class="eyebrow">Service Desk · ${T('شبیه‌سازی', 'Simulation', 'Simulation')}</div><h1>${T('شبیه‌ساز سیستم تیکت', 'Ticketsystem-Simulator', 'Ticket system simulator')}</h1>
<p class="page-description">${T('تو در میز خدمات سطح ۱ یک شرکت تمرینی کار می‌کنی. یک تیکت از صف بردار، از کاربر سؤال بپرس، نوع و دسته و اولویت را تعیین کن، یادداشت بنویس و تیکت را حل یا ارجاع کن. پاسخ‌های کاربر شبیه‌سازی شده‌اند؛ امتیاز انتخاب‌هایت را می‌سنجد، نه کیفیت متنت را.', 'Du arbeitest im 1st Level Service Desk einer Übungsfirma. Nimm ein Ticket aus der Warteschlange, stelle Rückfragen, ordne Typ, Kategorie und Priorität ein, dokumentiere und löse oder leite weiter. Die Antworten der Benutzer sind simuliert; die Punkte bewerten deine Auswahl, nicht die Qualität deiner Texte.', 'You work on the 1st level service desk of a practice company. Take a ticket from the queue, ask questions, set type, category and priority, document, then resolve or forward. User answers are simulated; the score checks your choices, not the quality of your writing.')}</p>
<nav class="td-tabs" aria-label="${E(T('بخش‌های شبیه‌ساز', 'Bereiche des Simulators', 'Simulator sections'))}">${tabs.map(([h, l]) => `<a href="#ticketdesk${h ? '/' + h : ''}" ${sub === h ? 'aria-current="page"' : ''}>${E(l)}</a>`).join('')}</nav>`;
}
const pill = st => `<span class="td-st td-st-${st}">${E(L(STATUS[st]))}</span>`;
const chan = t => L(TD.channels[t.ch]);
const whoFull = t => `${E(whoName(t))} <span class="micro">· ${E(L(t.who.d))}</span>`;

function queueView() {
 const st = store(), done = TD.tickets.filter(t => st[t.id]), avg = done.length ? Math.round(done.reduce((s, t) => s + st[t.id].best, 0) / done.length) : 0;
 const rows = TD.tickets.map(t => {
  const c = caseOf(t), r = S.run[t.id], s = st[t.id], status = r && r.status !== 'new' && !r.res ? r.status : s ? (s.fwd ? 'fwd' : 'solved') : 'new';
  return `<tr class="${s ? 'td-done' : ''}"><td><bdi class="td-no">${E(t.no)}</bdi></td><td><a class="text-link" href="#ticketdesk/${t.id}">${E(L(c).t)}</a></td><td>${whoFull(t)}</td><td>${E(chan(t))}</td><td>${hhmm(startMin(t))}</td><td>${pill(status)}</td><td>${s ? `<b>${num(s.best)}</b>/${num(100)}` : '–'}</td></tr>`;
 }).join('');
 return `${head('')}<section class="card td-sum"><p><b>${num(done.length)}</b> / ${num(TD.tickets.length)} ${T('تیکت انجام شد', 'Tickets bearbeitet', 'tickets handled')}${done.length ? ` · ${T('میانگین', 'Durchschnitt', 'average')} <b>${num(avg)}</b> ${T('امتیاز', 'Punkte', 'points')}` : ''}</p><p class="micro">${T('ترتیب پیشنهادی: اول تیکت‌های P1 را پیدا کن. اولویت را خودت در تیکت تعیین می‌کنی.', 'Tipp: Finde zuerst die Tickets, die P1 sind. Die Priorität legst du selbst im Ticket fest.', 'Tip: find the P1 tickets first. You set the priority yourself inside the ticket.')}</p></section>
<section class="card table-wrap td-queue"><table aria-label="${E(T('صف تیکت‌ها', 'Warteschlange', 'Queue'))}"><thead><tr><th>${E(T('شماره', 'Nummer', 'Number'))}</th><th>${E(T('موضوع', 'Betreff', 'Subject'))}</th><th>${E(T('گزارش‌دهنده', 'Melder', 'Reporter'))}</th><th>${E(T('کانال', 'Kanal', 'Channel'))}</th><th>${E(T('ورود', 'Eingang', 'Received'))}</th><th>${E(T('وضعیت', 'Status', 'Status'))}</th><th>${E(T('امتیاز', 'Punkte', 'Score'))}</th></tr></thead><tbody>${rows}</tbody></table></section>`;
}

function infoView() {
 const I = TD.info[lang()] || TD.info.de;
 const matrix = `<div class="table-wrap"><table class="td-matrix"><thead><tr><th>${E(T('اثر ↓ / فوریت →', 'Auswirkung ↓ / Dringlichkeit →', 'Impact ↓ / urgency →'))}</th>${[1, 2, 3].map(u => `<th>${num(u)}</th>`).join('')}</tr></thead><tbody>${[1, 2, 3].map(i => `<tr><th>${num(i)}</th>${[1, 2, 3].map(u => { const p = prioOf(i, u); return `<td class="td-p td-p${p}">${E(L(J.prio[p]))}</td>`; }).join('')}</tr>`).join('')}</tbody></table></div><ul class="micro">${[1, 2, 3].map(i => `<li>${E(T('اثر ', 'Auswirkung ', 'Impact ') + L(IMP[i]))}</li>`).join('')}${[1, 2, 3].map(u => `<li>${E(T('فوریت ', 'Dringlichkeit ', 'Urgency ') + L(URG[u]))}</li>`).join('')}</ul>`;
 const sla = `<div class="table-wrap"><table><thead><tr><th>${E(T('اولویت', 'Priorität', 'Priority'))}</th><th>${E(T('اولین پاسخ', 'Erste Reaktion', 'First response'))}</th><th>${E(T('هدف حل', 'Lösungsziel', 'Resolution target'))}</th></tr></thead><tbody>${[1, 2, 3, 4].map(p => `<tr><td>${E(L(J.prio[p]))}</td><td>${E(slaTxt(SLA[p][0]))}</td><td>${E(slaTxt(SLA[p][1]))}</td></tr>`).join('')}</tbody></table></div>`;
 const tools = `<div class="table-wrap"><table><thead><tr><th>${E(T('سیستم', 'System', 'System'))}</th><th>${E(T('نوع', 'Art', 'Type'))}</th><th>${E(T('معمولاً در', 'Typisch bei', 'Typically used by'))}</th></tr></thead><tbody>${TD.info.tools.map(([n, a, b]) => `<tr><td dir="ltr"><b>${E(n)}</b></td><td>${E(L(a))}</td><td>${E(L(b))}</td></tr>`).join('')}</tbody></table></div>`;
 return `${head('info')}${I.map(([h, html]) => `<section class="card td-info"><h2>${E(h)}</h2>${html.replace('@MATRIX@', matrix).replace('@SLA@', sla).replace('@TOOLS@', tools)}</section>`).join('')}
<section class="card"><a class="btn" href="#ticketdesk">${E(T('برو به صف تیکت‌ها', 'Zur Warteschlange', 'Go to the queue'))}</a></section>`;
}

function bubble(t, item) {
 const time = `<span class="td-time">${hhmm(item.m)}</span>`;
 if (item.k === 'msg') { const c = caseOf(t); return `<div class="td-b td-user"><div class="td-bh"><b>${E(whoName(t))}</b> · ${E(chan(t))} ${time}</div><p>${E(L(c).msg)}</p>${deLine(c.de.msg)}</div>`; }
 if (item.k === 'q') return `<div class="td-b td-tech"><div class="td-bh"><b>${E(T('تو (سطح ۱)', 'Du (1st Level)', 'You (1st level)'))}</b> ${time}</div><ul>${item.ids.map(id => `<li>${E(qText(t, id))}${deLine(qText(t, id, 'de'))}</li>`).join('')}</ul></div>`;
 if (item.k === 'a') return `<div class="td-b td-user"><div class="td-bh"><b>${E(whoName(t))}</b> ${time}</div>${item.ids.map(id => `<p>${E(aText(t, id))}</p>${deLine(aText(t, id, 'de'))}`).join('')}</div>`;
 if (item.k === 'typing') return `<div class="td-b td-user td-typing" role="status"><span class="micro">${E(whoName(t) + T(' دارد می‌نویسد …', ' schreibt …', ' is typing …'))}</span></div>`;
 return '';
}

function sel(name, val, opts, label) {
 return `<label class="td-f"><span>${E(label)}</span><select data-tdf="${name}"><option value="">${E(T('انتخاب کن …', 'Bitte wählen …', 'Choose …'))}</option>${opts.map(([v, l]) => `<option value="${v}"${String(val) === String(v) ? ' selected' : ''}>${E(l)}</option>`).join('')}</select></label>`;
}

function ticketView(t) {
 const c = caseOf(t), r = run(t), closed = !!r.res, ids = qIds(t).filter(id => !r.asked.includes(id));
 const p = r.f.imp && r.f.urg ? prioOf(+r.f.imp, +r.f.urg) : 0;
 const thread = r.thread.map(x => bubble(t, x)).join('') + (r.busy ? bubble(t, { k: 'typing' }) : '');
 const ask = closed ? '' : `<fieldset class="td-ask"><legend>${E(T('سؤال از کاربر', 'Rückfrage an den Benutzer', 'Question to the user'))}</legend>${ids.length ? ids.map(id => `<label class="td-q"><input type="checkbox" data-tdq="${id}"${r.sel.includes(id) ? ' checked' : ''}><span>${E(qText(t, id))}${deLine(qText(t, id, 'de'))}</span></label>`).join('') + `<button class="btn" data-td="send"${r.busy ? ' disabled' : ''}>${E(T('فرستادن سؤال', 'Rückfrage senden', 'Send question'))}</button>` : `<p class="micro">${E(T('همهٔ سؤال‌ها پرسیده شد.', 'Alle Rückfragen gestellt.', 'All questions asked.'))}</p>`}</fieldset>`;
 const dis = closed ? ' disabled' : '';
 const fields = `<section class="card td-fields"><h2>${E(T('مشخصات تیکت', 'Ticketdaten', 'Ticket details'))}</h2>
${sel('type', r.f.type, Object.keys(TYPES).map(k => [k, L(TYPES[k])]), T('نوع', 'Typ', 'Type'))}
${sel('area', r.f.area, Object.keys(J.areas).map(k => [k, L(J.areas[k])]), T('دسته', 'Kategorie', 'Category'))}
${sel('imp', r.f.imp, [1, 2, 3].map(i => [i, L(IMP[i])]), T('اثر (Auswirkung)', 'Auswirkung', 'Impact'))}
${sel('urg', r.f.urg, [1, 2, 3].map(u => [u, L(URG[u])]), T('فوریت (Dringlichkeit)', 'Dringlichkeit', 'Urgency'))}
<p class="td-prio" aria-live="polite">${p ? `${E(T('اولویت', 'Priorität', 'Priority'))}: <span class="td-p td-p${p}">${E(L(J.prio[p]))}</span> <span class="micro">SLA ${E(T('نمونه', 'Beispiel', 'example'))}: ${E(T('پاسخ', 'Reaktion', 'response'))} ${E(slaTxt(SLA[p][0]))} · ${E(T('حل', 'Lösung', 'resolution'))} ${E(slaTxt(SLA[p][1]))}</span>` : `<span class="micro">${E(T('اولویت از اثر و فوریت حساب می‌شود.', 'Die Priorität ergibt sich aus Auswirkung und Dringlichkeit.', 'Priority is calculated from impact and urgency.'))}</span>`}</p>
<label class="td-f"><span>${E(T('یادداشت داخلی (فقط IT می‌بیند)', 'Interne Notiz (sieht nur die IT)', 'Internal note (IT only)'))}</span><textarea data-tdn rows="4" maxlength="4000"${dis} placeholder="${E(T('واقعیت‌ها، ساعت، متن خطا، چه چیزی بررسی شد. بدون گذرواژه.', 'Fakten, Uhrzeit, Fehlermeldung, was geprüft wurde. Keine Kennwörter.', 'Facts, time, error message, what was checked. No passwords.'))}">${E(r.note)}</textarea></label></section>`;
 const close = closed ? '' : `<section class="card td-close"><h2>${E(T('حل یا ارجاع', 'Lösen oder weiterleiten', 'Resolve or forward'))}</h2>
<div class="td-modes" role="radiogroup" aria-label="${E(T('روش بستن', 'Abschluss', 'Closing'))}"><label><input type="radio" name="td-mode" data-tdm="solve"${r.mode === 'solve' ? ' checked' : ''}> ${E(T('خودم حل می‌کنم', 'Selbst lösen', 'Resolve myself'))}</label><label><input type="radio" name="td-mode" data-tdm="fwd"${r.mode === 'fwd' ? ' checked' : ''}> ${E(T('ارجاع به گروه دیگر', 'An eine Gruppe weiterleiten', 'Forward to a group'))}</label></div>
${r.mode === 'solve' ? `<fieldset class="td-fix"><legend>${E(T('کدام علت و راه‌حل درست است؟', 'Welche Ursache und Lösung passt?', 'Which cause and solution fits?'))}</legend>${fixOpts(t).map(id => `<label class="td-q"><input type="radio" name="td-fix" data-tdx="${id}"${r.fix === id ? ' checked' : ''}><span>${E(fixText(id))}</span></label>`).join('')}</fieldset>` : ''}
${r.mode === 'fwd' ? `<label class="td-f"><span>${E(T('گروه مسئول', 'Zuständige Gruppe', 'Assignment group'))}</span><select data-tdg><option value="">${E(T('انتخاب کن …', 'Bitte wählen …', 'Choose …'))}</option>${groupsFwd.map(g => `<option value="${g}"${r.group === g ? ' selected' : ''}>${E(L(TD.groups[g]))}</option>`).join('')}</select></label>` : ''}
${r.mode ? `<label class="td-f"><span>${E(r.mode === 'fwd' ? T('یادداشت تحویل برای گروه بعدی', 'Übergabenotiz für die nächste Gruppe', 'Handover note for the next group') : T('پاسخ به کاربر (عمومی)', 'Antwort an den Benutzer (öffentlich)', 'Reply to the user (public)'))}</span><textarea data-tdt rows="3" maxlength="4000">${E(r.text)}</textarea></label>` : ''}<button class="btn" data-td="close">${E(r.mode === 'fwd' ? T('ارجاع تیکت', 'Ticket weiterleiten', 'Forward ticket') : r.mode === 'solve' ? T('بستن تیکت به‌عنوان حل‌شده', 'Ticket als gelöst schließen', 'Resolve ticket') : T('بستن تیکت', 'Ticket abschließen', 'Close ticket'))}</button>
${S.msg ? `<p class="notice td-err" role="alert">${E(S.msg)}</p>` : ''}</section>`;
 return `<p><a class="text-link" href="#ticketdesk">${E(T('→ بازگشت به صف', '← Zur Warteschlange', '← Back to the queue'))}</a></p>
<header class="td-head"><bdi class="td-no">${E(t.no)}</bdi>${pill(r.res ? (r.mode === 'fwd' ? 'fwd' : 'solved') : r.status)}<h2>${E(L(c).t)}</h2><p class="micro">${whoFull(t)} · ${E(chan(t))} · ${E(T('ورود', 'Eingang', 'received'))} ${hhmm(startMin(t))}</p></header>
${r.res ? resultView(t, r) : ''}
<div class="td-grid"><section class="card td-thread"><h2>${E(T('گفت‌وگو', 'Verlauf', 'Conversation'))}</h2><div class="td-log">${thread}</div>${ask}</section><div class="td-side">${fields}${close}</div></div>`;
}

function resultView(t, r) {
 const c = caseOf(t), d = L(c), g = r.res;
 return `<section class="card td-result" tabindex="-1" data-td-focus><h2>${E(T('نتیجه', 'Ergebnis', 'Result'))}: ${num(g.total)} / ${num(100)}</h2>
<div class="table-wrap"><table><tbody>${g.items.map(x => `<tr class="${x.got === x.max ? 'td-ok' : 'td-miss'}"><th scope="row">${E(x.label)}</th><td>${num(x.got)}/${num(x.max)}</td><td>${E(x.why)}</td></tr>`).join('')}</tbody></table></div>
<h3>${E(T('نمونهٔ کار حرفه‌ای', 'So würde es ein Profi machen', 'How a professional would do it'))}</h3>
<dl class="td-dl"><dt>${E(T('علت و راه‌حل', 'Ursache und Lösung', 'Cause and solution'))}</dt><dd>${E(d.fix)}</dd><dt>${E(T('نمونهٔ یادداشت تیکت', 'Beispiel-Ticketnotiz', 'Sample ticket note'))}</dt><dd>${E(d.note)}${deLine(c.de.note)}</dd><dt>${E(T('نمونهٔ جمله به کاربر', 'Beispielsatz an den Benutzer', 'Sample words to the user'))}</dt><dd>${E(d.say)}${deLine(c.de.say)}</dd><dt>${E(T('چه وقت ارجاع', 'Wann weiterleiten', 'When to forward'))}</dt><dd>${E(d.esc)}</dd></dl>
<p><a class="text-link" href="#support/${t.id}">${E(T('کل این مورد با قدم‌های حل', 'Den ganzen Fall mit Lösungsschritten öffnen', 'Open the full case with solution steps'))}</a></p>
<button class="btn secondary" data-td="reset">${E(T('دوباره از اول', 'Noch einmal von vorn', 'Start again'))}</button> <a class="btn" href="#ticketdesk">${E(T('تیکت بعدی', 'Nächstes Ticket', 'Next ticket'))}</a></section>`;
}

function view(focus) { const t = tById(focus); return focus === 'info' ? infoView() : t && caseOf(t) ? ticketView(t) : queueView(); }

/* ---------- Seite, Aktionen ---------- */
let cur = '';
function page(focus) { cur = focus || ''; S.msg = ''; return `<div id="td-root" class="td work-page">${view(cur)}</div>`; }
function title() { return T('شبیه‌ساز سیستم تیکت', 'Ticketsystem-Simulator', 'Ticket system simulator'); }
function draw(focusSel) {
 const root = document.getElementById('td-root'); if (!root) return;
 const ae = document.activeElement, keep = focusSel || (ae && root.contains(ae) ? ['data-tdf', 'data-tdq', 'data-tdm', 'data-tdx', 'data-td'].filter(k => ae.hasAttribute(k)).map(k => `[${k}="${CSS.escape(ae.getAttribute(k))}"]`).join('') : '');
 root.innerHTML = view(cur);
 const el = keep && root.querySelector(keep); if (el) el.focus();
}
function mount(focus) { cur = focus || ''; const f = document.querySelector('#td-root [data-td-focus]'); if (f) f.focus(); }

function save(t, r) {
 const st = store(), old = st[t.id];
 st[t.id] = { best: Math.max(r.res.total, old ? old.best : 0), last: r.res.total, n: Math.min((old ? old.n : 0) + 1, 999), fwd: r.mode === 'fwd' };
 W() && W().persist();
}
function act(kind, t) {
 const r = run(t);
 if (kind === 'send') {
  if (!r.sel.length) { S.msg = ''; draw(); const b = document.querySelector('#td-root [data-td="send"]'); if (b) { b.insertAdjacentHTML('afterend', `<p class="notice td-err" role="alert">${E(T('اول دست‌کم یک سؤال را انتخاب کن.', 'Wähle zuerst mindestens eine Rückfrage.', 'Choose at least one question first.'))}</p>`); } return; }
  const ids = r.sel.filter(x => !r.asked.includes(x)); r.sel = []; if (!ids.length) { draw(); return; } r.asked.push(...ids);
  r.thread.push({ k: 'q', ids, m: r.clock }); r.clock += 2; r.status = 'wait'; r.busy = true; draw('[data-td="send"]');
  const delay = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 700;
  setTimeout(() => { r.busy = false; r.thread.push({ k: 'a', ids, m: r.clock }); r.clock += 3; r.status = 'work'; if (cur === t.id) draw(); }, delay);
  return;
 }
 if (kind === 'close') {
  const miss = [];
  if (!r.f.type) miss.push(T('نوع', 'Typ', 'type')); if (!r.f.area) miss.push(T('دسته', 'Kategorie', 'category'));
  if (!r.f.imp) miss.push(T('اثر', 'Auswirkung', 'impact')); if (!r.f.urg) miss.push(T('فوریت', 'Dringlichkeit', 'urgency'));
  if (!r.mode) miss.push(T('حل یا ارجاع', 'Lösen oder Weiterleiten', 'resolve or forward')); if (r.mode === 'solve' && !r.fix) miss.push(T('راه‌حل', 'Lösung', 'solution')); if (r.mode === 'fwd' && !r.group) miss.push(T('گروه', 'Gruppe', 'group'));
  if (miss.length) { S.msg = T('هنوز کامل نیست: ', 'Noch nicht vollständig: ', 'Not complete yet: ') + miss.join(T('، ', ', ', ', ')); draw(); return; }
  S.msg = ''; r.res = grade(t, r); r.status = r.mode === 'fwd' ? 'fwd' : 'solved'; save(t, r); draw('[data-td-focus]'); window.scrollTo && window.scrollTo({ top: 0 });
  return;
 }
 if (kind === 'reset') { delete S.run[t.id]; S.msg = ''; draw(); }
}
function onEvent(e) {
 const root = e.target.closest && e.target.closest('#td-root'); if (!root) return;
 const t = tById(cur); const el = e.target;
 if (e.type === 'click') { const b = el.closest('[data-td]'); if (b && t) { e.preventDefault(); act(b.dataset.td, t); } return; }
 if (!t) return;
 const r = run(t);
 if (el.matches('[data-tdq]')) { if (e.type !== 'change') return; const id = el.dataset.tdq; r.sel = r.sel.filter(x => x !== id).concat(el.checked ? [id] : []); return; }
 if (el.matches('[data-tdn]')) { r.note = el.value; return; }
 if (el.matches('[data-tdt]')) { r.text = el.value; return; }
 if (e.type !== 'change') return;
 if (el.matches('[data-tdf]')) { r.f[el.dataset.tdf] = el.value; if (r.status === 'new') r.status = 'work'; draw(); return; }
 if (el.matches('[data-tdm]')) { r.mode = el.dataset.tdm; S.msg = ''; draw(); return; }
 if (el.matches('[data-tdx]')) { r.fix = el.dataset.tdx; return; }
 if (el.matches('[data-tdg]')) { r.group = el.value; return; }
}
['click', 'change', 'input'].forEach(ev => document.addEventListener(ev, onEvent));

window.ArefiExt = Object.assign(window.ArefiExt || {}, { ticketdesk: { page, mount, title } });
window.ArefiTicketDesk = { grade, tickets: TD.tickets };
})();
