/* Arefi ITPraxis Service Worker 2.16.8 · d3102c0b17d9 */
const SCOPE = self.registration.scope;
const PREFIX = 'arefi-itpraxis-' + SCOPE + ':';
const CACHE = PREFIX + '2.16.8-d3102c0b17d9';
const ASSETS = ["./", "ap-quiz.js", "app.css", "app.js", "arefi-icon.svg", "autobackup.js", "brand-theme.css", "brand.js", "commands.js", "content.js", "course-plus.js", "course-view.js", "courses-hub.js", "curriculum.js", "dark-theme.css", "desktop.js", "enterprise.js", "fonts/Neometric-Bold.woff", "fonts/Neometric-Regular.woff", "fonts/Neometric-SemiBold.woff", "fonts/OFL.txt", "fonts/Pinar-Bold.woff2", "fonts/Pinar-Medium.woff2", "fonts/Pinar-Regular.woff2", "fonts/Pinar-SemiBold.woff2", "fonts/PortadaTextARA-Bold.woff", "fonts/PortadaTextARA-Book.woff", "fonts/PortadaTextARA-Regular.woff", "fonts/PortadaTextARA-Semibold.woff", "fonts/Rokh-Bold.woff", "fonts/Rokh-Regular.woff", "fonts/Rokh-SemiBold.woff", "hardware-exercises.js", "hardware-info.js", "hardware-library.css", "hardware-library.js", "icons/icon-180.png", "icons/icon-192.png", "icons/icon-512.png", "icons/maskable-192.png", "icons/maskable-512.png", "index.html", "infrastructure.js", "k-ap-1.js", "k-ap.js", "k-ccna-1.js", "k-ccna-2.js", "k-ccna-3.js", "k-ccna-topo.js", "k-ccna.js", "k-cli-1.js", "k-cli-2.js", "k-cli-3.js", "k-cli.js", "k-dev-1.js", "k-dev-2.js", "k-dev.js", "k-infra-1.js", "k-infra-2.js", "k-infra-3.js", "k-infra.js", "k-m365-1.js", "k-m365-2.js", "k-m365-3.js", "k-m365.js", "k-modern-1.js", "k-modern-2.js", "k-modern-3.js", "k-modern.js", "k-net-1.js", "k-net-2.js", "k-net-3.js", "k-net-topo.js", "k-net.js", "k-ops-1.js", "k-ops-2.js", "k-ops-3.js", "k-ops.js", "k-plan-1.js", "k-plan-2.js", "k-plan-3.js", "k-plan-p-gross.js", "k-plan-p-klein.js", "k-plan-p-mittel.js", "k-plan-p-privat.js", "k-plan-p-vergleich.js", "k-plan.js", "k-tools-1.js", "k-tools-2.js", "k-tools-3.js", "k-tools.js", "languages.js", "learning.js", "lesson.css", "lessonview.js", "locale-data.js", "lx-course-1.js", "lx-course-2.js", "lx-course-3.js", "lx-course-4.js", "lx-course.js", "lx-plus-1.js", "lx-plus-2.js", "lx-plus-3.js", "manifest.webmanifest", "platform.js", "project-view.js", "search.js", "subnet-trainer.js", "support-linux.js", "theme-init.js", "ticket-data.js", "ticketdesk.js", "topo.js", "training-start.css", "training-start.js", "training.js", "work-cases-2.js", "work-cases-3.js", "work-cases-4.js", "work-data.js", "work-english.js", "work-net.js", "work-run.js", "work-sig.js", "workplace.js", "ws-course-1.js", "ws-course-2.js", "ws-course-3.js", "ws-course-4.js", "ws-course.css", "ws-course.js", "ws-plus-1.js", "ws-plus-2.js", "ws-plus-3.js"].map(file => new URL(file, SCOPE).href);
const SHELL = new URL('index.html', SCOPE).href;
const ASSET_URLS = new Set(ASSETS);
self.addEventListener('install', e => {
  const requests = ASSETS.map(url => new Request(url, { cache: 'reload' }));
  e.waitUntil(caches.open(CACHE).then(cache => cache.addAll(requests)));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key =>
    (key.startsWith(PREFIX) && key !== CACHE) || /^arefi-itpraxis-\d/.test(key)
  ).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('message', e => { if (e.data === 'skip') self.skipWaiting(); });
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);
  url.search = '';
  url.hash = '';
  if (!ASSET_URLS.has(url.href)) return;
  const key = e.request.mode === 'navigate' && url.href === SCOPE ? SHELL : url.href;
  e.respondWith(caches.open(CACHE).then(cache => cache.match(key)).then(response =>
    response || fetch(e.request)
  ));
});
